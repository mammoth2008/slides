-- 必须先结束 20-cases 各事务，确认 Grade=60、SC_U 为空
-- ALTER 位于测试事务之外，不把 DDL 当成可回滚的数据更新
ALTER TABLE SC_U ADD CONSTRAINT CK_Log_Test CHECK (NewGrade<=65);
START TRANSACTION;
UPDATE SC SET Grade=70 WHERE Sno='S01' AND Cno='C01';
-- 预期 UPDATE 报错；在客户端手工继续以下查询
SELECT * FROM SC;
SELECT * FROM SC_U;
-- 预期 Grade=60、空日志
ROLLBACK;
ALTER TABLE SC_U DROP CHECK CK_Log_Test;
