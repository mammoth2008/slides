-- 小样本结果两行：C001,01,80 和 C002,01,95；SQL未指定顺序
SELECT Cno, ClassNo, Grade FROM SC
WHERE Sno = '20260001' AND Term = '2026-1';
-- 小样本结果两行：20260001,王平,80 和 20260002,张明,70
SELECT s.Sno, s.Sname, sc.Grade
FROM SC AS sc JOIN Student AS s ON s.Sno = sc.Sno
WHERE sc.Cno = 'C001' AND sc.Term = '2026-1'
  AND sc.ClassNo = '01';
