-- 方案C在B基础上再增加；不是未经测量就建议两条都建
CREATE INDEX ix_student_term ON SC
 (Sno, Term, Cno, ClassNo, Grade);
