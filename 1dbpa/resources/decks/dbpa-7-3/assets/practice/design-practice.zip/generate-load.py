"""生成确定性合成负载 SQL；只写输出文件，不连接数据库。默认60万SC行。"""
import argparse
from pathlib import Path

def generate(output, students=30000, courses=500, classes=8, per_class=50):
    if not (1 <= courses <= 999 and 1 <= classes <= 99 and 1 <= per_class <= students <= 30000):
        raise ValueError('范围：课程1..999，班数1..99，每班人数不超过学生数，学生最多30000')
    terms=('2025-1','2025-2','2026-1')
    counts={}
    with Path(output).open('x',encoding='utf-8') as f:
        f.write('-- 人工合成均匀负载，不是实际学校记录；只装入00-schema.sql建立的空库\n')
        def emit(table,rows):
            count=0;batch=[]
            for row in rows:
                vals=','.join('NULL' if v is None else str(v) if isinstance(v,int) else "'"+v.replace("'","''")+"'" for v in row)
                batch.append('('+vals+')');count+=1
                if len(batch)==1000:
                    f.write('INSERT INTO '+table+' VALUES\n'+',\n'.join(batch)+';\n');batch=[]
            if batch:f.write('INSERT INTO '+table+' VALUES\n'+',\n'.join(batch)+';\n')
            counts[table]=count
        emit('Student',((str(20260000+i),'学生'+str(i)) for i in range(1,students+1)))
        emit('Course',((f'C{i:03d}','课程'+str(i),3) for i in range(1,courses+1)))
        emit('Teacher',[('T01','教师一'),('T02','教师二')])
        emit('TeachingClass',((f'C{c:03d}',term,f'{cl:02d}','T01' if c%2 else 'T02',per_class+30) for term in terms for c in range(1,courses+1) for cl in range(1,classes+1)))
        def selection_rows():
            for term in terms:
                for c in range(1,courses+1):
                    for cl in range(1,classes+1):
                        offset=((c-1)*classes+cl-1)*per_class
                        for j in range(per_class):
                            sno=str(20260001+(offset+j)%students)
                            yield (sno,f'C{c:03d}',term,f'{cl:02d}',term[:4]+'-09-01 09:00:00' if term.endswith('1') else str(int(term[:4])+1)+'-03-01 09:00:00',(offset+j)%101)
        emit('SC',selection_rows())
    return counts
if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',required=True)
    args=ap.parse_args()
    print(generate(args.output))
