-- 仅在00+01的小样本上执行；教学评价是独立扩展
CREATE TABLE TeachingEvaluation (
 EvalId CHAR(3) PRIMARY KEY,
 Sno CHAR(8) NOT NULL,
 Cno CHAR(4) NOT NULL,
 Term CHAR(6) NOT NULL,
 ClassNo CHAR(2) NOT NULL,
 Content VARCHAR(200) NOT NULL,
 Feedback VARCHAR(200),
 FOREIGN KEY (Sno,Cno,Term,ClassNo) REFERENCES SC(Sno,Cno,Term,ClassNo)
) ENGINE=InnoDB;
INSERT INTO TeachingEvaluation VALUES
 ('E01','20260001','C001','2026-1','01','讲解清楚','谢谢反馈'),
 ('E02','20260002','C001','2026-1','01','希望增加演示','下次补充'),
 ('E03','20260001','C002','2026-1','01','实验充分','谢谢反馈');
-- 常量用户仅用于观察行列范围，不是动态身份验证实现
CREATE VIEW TeacherT01Evaluation AS
SELECT e.Cno,e.Term,e.ClassNo,e.Content,e.Feedback
FROM TeachingEvaluation e JOIN TeachingClass t
 ON e.Cno=t.Cno AND e.Term=t.Term AND e.ClassNo=t.ClassNo
WHERE t.Tno='T01';
CREATE VIEW TeacherT02Evaluation AS
SELECT e.Cno,e.Term,e.ClassNo,e.Content,e.Feedback
FROM TeachingEvaluation e JOIN TeachingClass t
 ON e.Cno=t.Cno AND e.Term=t.Term AND e.ClassNo=t.ClassNo
WHERE t.Tno='T02';
CREATE VIEW Student20260001Evaluation AS
SELECT e.Cno,e.Term,e.ClassNo,t.Tno,e.Content,e.Feedback
FROM TeachingEvaluation e JOIN TeachingClass t
 ON e.Cno=t.Cno AND e.Term=t.Term AND e.ClassNo=t.ClassNo
WHERE e.Sno='20260001';
CREATE VIEW Student20260002Evaluation AS
SELECT e.Cno,e.Term,e.ClassNo,t.Tno,e.Content,e.Feedback
FROM TeachingEvaluation e JOIN TeachingClass t
 ON e.Cno=t.Cno AND e.Term=t.Term AND e.ClassNo=t.ClassNo
WHERE e.Sno='20260002';
SELECT * FROM TeacherT01Evaluation;
SELECT * FROM TeacherT02Evaluation;
SELECT * FROM Student20260001Evaluation;
SELECT * FROM Student20260002Evaluation;
-- 本脚本不创建账户。实际部署另将视图授予对应账户，并限制基本表及其他用户视图访问
