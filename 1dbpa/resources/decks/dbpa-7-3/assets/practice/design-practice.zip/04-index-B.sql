-- 在方案A的相同快照上增加；实际先检查已有索引避免重复
CREATE INDEX ix_roster ON SC
 (Cno, Term, ClassNo, Grade, Sno);
