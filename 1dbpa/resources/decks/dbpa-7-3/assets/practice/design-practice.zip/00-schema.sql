-- 固定语法参考：MySQL 8.4 / InnoDB。只在新建的空练习库中执行
-- 不包含 DROP、授权或容量并发控制；这是数据约束样本
CREATE TABLE Student (
  Sno CHAR(8) PRIMARY KEY,
  Sname VARCHAR(40) NOT NULL
) ENGINE=InnoDB;
CREATE TABLE Course (
  Cno CHAR(4) PRIMARY KEY,
  Cname VARCHAR(80) NOT NULL,
  Credit SMALLINT NOT NULL CHECK (Credit > 0)
) ENGINE=InnoDB;
CREATE TABLE Teacher (
  Tno CHAR(3) PRIMARY KEY,
  Tname VARCHAR(40) NOT NULL
) ENGINE=InnoDB;
CREATE TABLE TeachingClass (
  Cno CHAR(4) NOT NULL,
  Term CHAR(6) NOT NULL,
  ClassNo CHAR(2) NOT NULL,
  Tno CHAR(3) NOT NULL,
  Capacity INTEGER NOT NULL CHECK (Capacity > 0),
  PRIMARY KEY (Cno, Term, ClassNo),
  FOREIGN KEY (Cno) REFERENCES Course(Cno),
  FOREIGN KEY (Tno) REFERENCES Teacher(Tno)
) ENGINE=InnoDB;
CREATE TABLE SC (
  Sno CHAR(8) NOT NULL,
  Cno CHAR(4) NOT NULL,
  Term CHAR(6) NOT NULL,
  ClassNo CHAR(2) NOT NULL,
  AppliedAt DATETIME NOT NULL,
  Grade SMALLINT CHECK (Grade BETWEEN 0 AND 100),
  PRIMARY KEY (Sno, Cno, Term, ClassNo),
  FOREIGN KEY (Sno) REFERENCES Student(Sno),
  FOREIGN KEY (Cno, Term, ClassNo)
    REFERENCES TeachingClass(Cno, Term, ClassNo)
) ENGINE=InnoDB;
