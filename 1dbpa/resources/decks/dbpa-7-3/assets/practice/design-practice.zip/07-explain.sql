SELECT VERSION();
SHOW CREATE TABLE SC;
SHOW INDEX FROM SC;
EXPLAIN SELECT Cno,ClassNo,Grade FROM SC
 WHERE Sno='20260001' AND Term='2026-1';
EXPLAIN SELECT s.Sno,s.Sname,sc.Grade
 FROM SC sc JOIN Student s ON s.Sno=sc.Sno
 WHERE sc.Cno='C001' AND sc.Term='2026-1' AND sc.ClassNo='01';
-- 保存原始计划，记录实际使用索引、估计扫描行数、覆盖情况
-- EXPLAIN估计不是实际查询时延；索引空间另用目标引擎的统计工具测量并注明口径
