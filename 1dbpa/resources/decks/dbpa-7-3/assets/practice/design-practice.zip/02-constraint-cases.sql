-- 在小样本上逐条执行；拒绝是预期结果，不要当作整个文件应当无报错
-- 先核对 TeachingClass=3 行，SC=3 行
SELECT COUNT(*) FROM TeachingClass;
SELECT COUNT(*) FROM SC;
-- 预期：主码拒绝重复，SC仍3行
INSERT INTO SC VALUES
 ('20260001','C001','2026-1','01','2026-09-01 10:00:00',NULL);
-- 预期：组合外码拒绝不存在的99班，SC仍3行
INSERT INTO SC VALUES
 ('20260001','C001','2026-1','99','2026-09-01 10:00:00',NULL);
-- 预期：拒绝不存在的学生，SC仍3行
INSERT INTO SC VALUES
 ('20269999','C001','2026-1','01','2026-09-01 10:00:00',NULL);
-- 预期：CHECK拒绝130，原成绩80保留
UPDATE SC SET Grade=130
WHERE Sno='20260001' AND Cno='C001' AND Term='2026-1' AND ClassNo='01';
-- 1:1扩展示例；允许院长暂缺
CREATE TABLE College (
 CollNo CHAR(2) PRIMARY KEY,
 DeanTno CHAR(3) UNIQUE,
 FOREIGN KEY (DeanTno) REFERENCES Teacher(Tno)
) ENGINE=InnoDB;
INSERT INTO College VALUES ('D1','T01');
-- 预期：UNIQUE拒绝同一教师任两院院长
INSERT INTO College VALUES ('D2','T01');
-- 预期：FK拒绝不存在的教师
INSERT INTO College VALUES ('D2','T99');
-- 预期：接受。两位不同院长各在一所学院
INSERT INTO College VALUES ('D2','T02');
