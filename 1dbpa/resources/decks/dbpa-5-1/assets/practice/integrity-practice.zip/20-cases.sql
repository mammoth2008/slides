-- 每次只执行一个编号；预期报错后继续手工查询，不把全文件一次运行
-- 1 重复主码：预期拒绝
INSERT INTO SC VALUES ('S01','C01',85);
-- 2 非法外码：预期拒绝
INSERT INTO SC VALUES ('S999','C01',80);
-- 3 越界成绩：预期拒绝，原值仍为 80
UPDATE SC SET Grade=130 WHERE Sno='S01' AND Cno='C01';
SELECT * FROM SC ORDER BY Sno,Cno;
-- 4 默认参照动作：预期拒绝，Student 与 SC 不变
DELETE FROM Student WHERE Sno='S01';
SELECT * FROM Student ORDER BY Sno;
SELECT * FROM SC ORDER BY Sno,Cno;
-- 5 CHECK 的 UNKNOWN：本例 Ssex 可空；仅在独立事务内测试
START TRANSACTION;
UPDATE Student SET Ssex=NULL WHERE Sno='S01';
SELECT Sno,Ssex FROM Student WHERE Sno='S01';
ROLLBACK;

-- 6 可空 UNIQUE：记录两个 NULL 的实际处理；不与空字符串混淆
START TRANSACTION;
UPDATE Student SET Semail=NULL WHERE Sno IN ('S01','S02');
SELECT Sno,Semail FROM Student ORDER BY Sno;
ROLLBACK;
