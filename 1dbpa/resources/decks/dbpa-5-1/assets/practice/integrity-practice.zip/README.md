# DBPA 5.1 完整性练习

本包与课件共用一份 Student、Course、SC 基线，MySQL 8.4 是编写语法参照，不代表授课时的最新正式版本。本机没有 mysql/mysqld，本轮未作 MySQL 实机运行；不要把下面的预期结果冒充运行记录。

## 开始与顺序

1. 使用教师指定的 MySQL 实验环境，创建专用空实验库并选中它，不在业务库或以前的实验表上执行
2. 执行 `SELECT VERSION();`，记录版本、客户端和日期
3. 运行 00-start.sql 一次；应有 2 名学生、2 门课、3 条选课；Student 已定义非空姓名和唯一邮箱，SC 始终包含 Grade
4. 按课件 c1、d1 执行 10-constraints.sql 的对应部分；它们是 ALTER，不再创建同名表
5. 20-cases.sql 每次只做一个编号，预期失败的语句之后手工执行 SELECT 复查，不以客户端中断表示整个实验失败
6. 30-actions.sql 是独立的级联／置空对照；40-range.sql 是独立的约束维护，不与 Student 的 S01/S02 混用

## 预期结果与观察

| 场景 | 预期 | 运行记录 |
| --- | --- | --- |
| 重复 S01/C01 | 拒绝，原 80 分保留 | 待填写 |
| 插入 S999/C01 | 拒绝，SC 仍三行 | 待填写 |
| 写入 130 | 拒绝，原 80 分保留 | 待填写 |
| 从 Student 删除 S01 | 拒绝，两表不变 | 待填写 |
| SCCascade 删除父行 S01 | 子表剩 S02/C01/70 | 待填写 |
| Major 删除 M1 | S01 的 MajorId 为 NULL，S02 仍为 M2 | 待填写 |
| 可空性别写 NULL | CHECK 为 UNKNOWN，不因此拒绝；回滚恢复 | 待填写 |
| 两个邮箱同时为 NULL | 参照 MySQL 8.4 可空唯一索引规则，预期允许；须填本机结果 | 待填写 |
| IdDemo 扩展到 3 字头 | 两条旧行保留，31000001 可加入 | 待填写 |

## 产品边界查阅入口

- 主码、外码、非空、唯一、CHECK 是本包的实验对象；域和 ASSERTION 仅作教材概念比较，不在本包运行
- 两个 NULL 对可空 UNIQUE 的处理、CHECK 三值逻辑、外码默认动作及 DROP CHECK 语法，以所用版本的手册与实际记录为准
- 课程已有参考：[MySQL 8.4 主码与唯一约束](https://dev.mysql.com/doc/refman/8.4/en/constraint-primary-key.html)、[CHECK](https://dev.mysql.com/doc/refman/8.4/en/create-table-check-constraints.html)、[外码](https://dev.mysql.com/doc/refman/8.4/en/create-table-foreign-keys.html)、[ALTER TABLE](https://dev.mysql.com/doc/refman/8.4/en/alter-table.html)
- 本轮没有重新联网核验这些参考。使用版本不同或实际结果不同，记录版本、SQL、错误与结果表后再判断，不改掉旧数据来迎合预期
