-- 在专用空实验库内运行；不删除已有库或表
CREATE TABLE Student (
  Sno CHAR(8) PRIMARY KEY,
  Sname VARCHAR(20) NOT NULL,
  Semail VARCHAR(100) UNIQUE,
  Ssex CHAR(6),
  Smajor VARCHAR(40)
);
CREATE TABLE Course (Cno CHAR(5) PRIMARY KEY, Cname VARCHAR(40));
CREATE TABLE SC (
  Sno CHAR(8) NOT NULL, Cno CHAR(5) NOT NULL,
  Grade SMALLINT, PRIMARY KEY (Sno,Cno)
);
INSERT INTO Student VALUES
('S01','李宁','s01@example.invalid','女','计算机科学与技术'),
('S02','周敏','s02@example.invalid','男','数学');
INSERT INTO Course VALUES ('C01','数据库'),('C02','程序设计');
INSERT INTO SC VALUES ('S01','C01',80),('S01','C02',95),('S02','C01',70);
