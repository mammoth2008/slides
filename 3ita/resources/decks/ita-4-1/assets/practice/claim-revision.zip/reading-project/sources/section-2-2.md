# 作业完成时间：原文短摘录

Strömberg、Lei、Wu，The Generative AI Learning Penalty: Evidence from Chinese Secondary Education，2026 年 6 月固定稿。§2.2，原 PDF 物理页 6。原件 SHA-256：0e22d6db93cb8fce57a805b33d00d890d30212b3feec5e7322fc9f15fb39e838。

## 英文原文

We define homework completion time as the interval between retrieving an assignment and submitting the answers on the digital platform. The average homework completion time is 58 minutes. Although this variable may not be a perfect measure of the actual time spent on each homework assignment, it is a reasonable proxy for the time students spend on the weekend homework assignments on average.

## 中文导读（本轮备课编写）

定义是平台领取作业至提交答案的间隔，平均 58 分钟。作者提醒，它不能准确反映每次实际用时，但仍作为平均周末作业用时的合理代理。不能据此认定学生全程专注，也不能把该均值当成 AI 造成的变化。

本文件只含一个短段落；原 PDF 全文未包含在包内。原文身份入口：https://doi.org/10.2139/ssrn.6977138 。
