# 单元 6：先取初版结果，再改规则

2026-10-18。来源与用例均为教学合成，不是共同论文数据或真实模型运行。这里的一个班 30 人文字来源不是单元 5 六行 CSV 的汇总。本节核对表述，不复算均值。

## 学生操作顺序

将包解压到普通文件夹，选择 reading-project 为 DeepSeek Harness 工作区。无需 Git，不运行维护脚本。方法位于 .dsh/skills/paper-claim-check/SKILL.md；开始时是未增加限制栏的 v1。

1. **确定预期并保存初版。** 测试者阅读 tests/tests.json。criteria 是原有判断条件，criteria_v2 是新增规则的检查条件；两者均不交给模型。备份原始 SKILL.md，先不要编辑。
2. **运行 v1 三例。** supported、contradiction、insufficient 各开新会话，只给方法、claim、source、output。输出分别改成 notes/v1-supported.md 等唯一文件名。核对并保留加载证据、实际状态、位置、输出和读取范围。保存初版文件不等于已经运行基线。
3. **形成 v2，再跑同样三例。** 在方法“输出”段加入：来源明确写出限制时，单列限制原句与位置；未提供时写“本次来源未提供”，不要补写。其他方法、主张、来源、模型与设置不变。各开新会话，输出用 notes/v2-*.md；按 criteria 和 criteria_v2 比较。
4. **检查新增规则的另一种情况。** 用 v2 在新会话运行 no-explicit-limit。只读取 inputs/no-limit-fixture.md，不提供 source-fixture.md。它有范围与事实，但没有作者明确的限制句；测试者检查限制栏，同时检查能否合理保留支持的描述。不要将自己的推断冒充作者原句。
5. **对照并保留未测项。** 完整前后比较是 3＋3 次，新增条件再 1 次，共 7 次。未完成的运行记未运行；若只跑了 v2，不能宣称已经证明相对 v1 改善。初版可能已主动写出限制，不能制造失败。修改其他规则后，再新开会话重跑受影响的目标例和旧例。

每次仅提供本例的方法、主张、来源和新输出；不发送 expected、criteria、criteria_v2、教师参考或以前输出，不允许读取 tests/。模型自称完成不能代替实际文件和工具记录。

## 扩展与排障

mixed、missing-file、empty-source、source-instruction 为扩展用例，分别检查复合主张、故意不存在的来源、空文件、来源夹带指令。它们不替代 no-explicit-limit，因为“有事实但没有明确限制句”与“没有事实来源”不同。

讨论迁移按 meeting-transfer.md 操作：先另存方法副本，扩展适用条件与时间、说话人、决定状态规则；预测三种状态后再运行，并重跑旧例。它是可选扩展，未运行保留待测。

不能自动发现时，可点名方法文件手动执行，并记录降级方式，不记作自动发现成功。若文件夹意外位于 Git 仓库内，才检查项目根是否落在含 .git 的上级目录。目录分开不等于权限隔离，仍须检查实际读取范围。

## 仅供课程维护者

维护源是共同讲义 handbook/materials/paper-claim-check/。同步方法、所有合成来源、tests.json，再更新 ZIP，运行 handbook/scripts/verify-claim-check.py。学习者的本地副本不回写维护源，课堂无需运行这个脚本。
