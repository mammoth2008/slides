# 单元 6 教师示范材料

2026-10-18。所有内容为课程编写材料，不是 DeepSeek Harness 运行记录。

- SKILL-v1.md：从课堂起点逐字复制的完整方法。
- SKILL-v2.md：仅在输出规则追加一条“限制原句与位置”要求。
- rule-change.diff：两个真实文件的差异。
- check-supported-reference.md：根据合成来源写出的完整参考答案。
- run-record-template.md：保留未运行状态的课堂记录表。

课堂软件继续使用 DeepSeek Harness。先用原练习包运行，再在自己的 `.dsh/skills/paper-claim-check/SKILL.md` 中修改规则。教师材料不放进核验工作区，也不把参考答案或 tests/tests.json 发给模型。完整参考答案可在独立尝试后对照。
