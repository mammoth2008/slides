# 共同论文身份与固定版本

内部标识：stromberg-2026。
作者：David Strömberg、Victor Lei、Yanhui Wu。
题名：The Generative AI Learning Penalty: Evidence from Chinese Secondary Education。
版本：2026 年 6 月工作论文，未在本材料中当作已发表期刊论文。
入口：https://doi.org/10.2139/ssrn.6977138
固定 PDF SHA-256：0e22d6db93cb8fce57a805b33d00d890d30212b3feec5e7322fc9f15fb39e838。

本包仅提供[短摘录](evidence-excerpts.md)与教师概述。全文不在包内；学生从课程原材料取得固定版本后保存为 `originals/paper.pdf`。全文回查和 Zotero 批注操作仍需要这个真实附件，短摘录不等于完整阅读。

教师概述的回查位置：研究对象 §2.1（物理页 5）；指标和基线 §2.2（物理页 6）；比较设计 §3（物理页 7–9）；第 6–10 月结果 §4.2（物理页 11）；因果解释限制 §5.2（物理页 19）。短摘录中只保存对应的有限句段，不能宣称包含全部识别条件。
