# 第 5.1 节：作业外包的行为模式（短摘录）

来源：Strömberg、Lei、Wu，The Generative AI Learning Penalty: Evidence from Chinese Secondary Education，2026 年 6 月固定稿，第 5.1 节 Outsourcing students 段，原 PDF 物理页 17。论文入口：https://doi.org/10.2139/ssrn.6977138 。本文件只含选定原文，不是全文转换稿。

## 英文原文

However, among AI students with homework scores above the baseline mean, higher homework scores are associated with lower exam scores. In this range, average homework time also falls: from 62 minutes at the baseline mean score of 100 to 43 minutes at 120 percent of the baseline mean. This suggests that high homework scores among AI students reflect greater reliance on AI assistance rather than better learning, consistent with the “homework outsourcing,” as opposed to “tutoring,” pattern of AI use.

## 中文导读（教学编写）

在所述 AI 使用者范围内，较高作业分数同时伴随较低考试分数与较短作业时间。作者认为这一模式与“作业外包”相符。请区分观察到的关系与作者据此提出的解释；这一段没有证明时间减少是唯一原因。是否有进一步限制，还需读取指定的第 5.2 节摘录。
