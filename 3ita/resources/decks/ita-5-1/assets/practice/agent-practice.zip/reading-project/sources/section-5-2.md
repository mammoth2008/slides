# 第 5.2 节：机制解释的限制（短摘录）

来源：Strömberg、Lei、Wu，The Generative AI Learning Penalty: Evidence from Chinese Secondary Education，2026 年 6 月固定稿，第 5.2 节 Discussion，原 PDF 物理页 19。论文入口：https://doi.org/10.2139/ssrn.6977138 。本文件只含选定原文，未提供整页或全文。

## 英文原文

The relationship between homework completion time and exam scores should not be interpreted as causal. Homework completion time after AI adoption allows us to characterize how the group of students whose learning is negatively affected use generative AI. Still, other factors that are correlated with our measured homework completion time may also contribute to the reduced learning.

## 中文导读（教学编写）

作业完成时间与考试成绩的关系不应解释为因果关系。作者用作业时间描述受影响学生的使用模式，同时提醒：与作业时间相关的其他因素也可能造成学习损失。请保留第 5.1 节已有模式证据，修正“唯一原因已被证明”的断言。
