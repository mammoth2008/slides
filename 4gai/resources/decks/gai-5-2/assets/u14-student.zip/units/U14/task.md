# U14 转写配音与字幕核查

候选形成性练习。建议30分钟，学生耗时尚未验证。仅提交本页微任务，不承接可选整题的完整交付或100分量规。

## 固定材料

读取本目录input.json。以下内容可打印使用。

```json
{
  "assetIds": [
    "AUD-003",
    "VID-003",
    "VID-004"
  ],
  "referenceVtt": "../../media/b05-speech-lab/originals/reference.vtt",
  "exerciseVtt": "../../media/b05-speech-lab/originals/exercise.vtt",
  "brief": "听课程实际合成语音，检查字幕中的否定、版本号和时间偏移。1秒附近首句、7秒附近第二句、13秒附近第三句；字幕参考是拟合成文本，须与真实声音核对。",
  "rules": [
    "本卡没有人名，不评价人名听辨。",
    "VID003/004视频原字节相同，区别是外置字幕，播放器不支持VTT时分别读字幕时间并用WAV回听。",
    "无法听清记待回听，不以参考文本冒作已听结论。离线阅读替代只能提交风险筛查，不取得回听证据。"
  ],
  "provenance": "identified_source_excerpt_and_teaching_construct",
  "backgroundSources": [
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/question-bank/records/Q-143.json",
      "sha256": "e3a7e2a3bf8092d8861177c45b62c7c94a76578d81224efd0b0e85f5bc41054e",
      "locator": "/inputs"
    },
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/cases/records/CASE-011.json",
      "sha256": "f33634ac38399aa162e03ca86bb9035c77e470516400862147ef068346f71510",
      "locator": "/studentTask/inputs"
    },
    {
      "path": "courses/gai/knowledge-map/content/nodes/A24.json",
      "sha256": "2b24e6a5df179f7d001449abb44d0e70d51d542fd0484f76c81601683a7a1de0",
      "locator": "whole_file"
    }
  ]
}
```

实际文件见以下清单。媒体为原字节副本。替代文字只支持相应的文字判断，不充作本人视听证据。

- [AUD-003](../../media/b05-speech-lab/originals/normal.wav)
- [VID-003](../../media/b05-speech-lab/originals/speech.mp4)
- [VID-004](../../media/b05-speech-lab/originals/speech.mp4)

## 必要动作

1. 先实际听AUD003或看VID003，记所用播放器和回听时间。
2. 对照exercise/reference VTT，定位否定、版本和第三句时间差，不能把参考文本当人工听录结论。
3. 在exercise副本修订文字/时间，保存修订VTT和回听记录；听不清处写待核。无声音路径只交筛查，回听保持待测。

## 提交与自查

提交一张证据单及本任务实际产物，保留原判断、修订、本人/AI贡献和未测范围。

- 回听或缺声状态如实记。
- 否定/版本/时间定位到素材。
- 取得修订VTT与理由。
- 筛查/回听/完整质检范围分开。

四项各0/1，仅作本微任务形成性自查。待补证据登记待补，未执行不能算实际操作通过。课程正式成绩归属由教师另行公布。

## 能力范围

- A24　真实合成语音/字幕局部核查与VTT修订，不含完整音视频制作或人名听辨。

需将选编微任务中的人名风险改为版本/时间风险，本卡无名字。

## 概念使用边界

实际历史TTS语音为输入，只练字幕核查，没有新ASR/TTS调用。
