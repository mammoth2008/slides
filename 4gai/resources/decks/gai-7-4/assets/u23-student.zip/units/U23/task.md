# U23 用Harness控制失败恢复与接管

候选形成性练习。建议30分钟，学生耗时尚未验证。仅提交本页微任务，不承接可选整题的完整交付或100分量规。

## 固定材料

读取本目录input.json。以下内容可打印使用。

```json
{
  "runtime": "../../runtime/u23/controller.cjs",
  "snapshot": "../../runtime/u23/interrupted.json",
  "editablePolicy": "../../runtime/u23/policy.json",
  "brief": "离线B07构造批次在J12写产物后、写完成位前中断。J13地点缺失，需要人工取得资料。先恢复基线，再在policy副本把stopOnMissing由false改true。",
  "rules": [
    "规则开启时，遇任一源字段缺失先返回takeover_pending和job/field/owner，保留原快照与产物，不继续调用recover。",
    "停止是本控制器的内存封套状态，B07原快照status不改为未知值。",
    "正常完整输入仍能恢复，重复恢复不重复产物。",
    "没有真实通知、模型、MCP、网络、数据库或业务动作。"
  ],
  "provenance": "teaching_construct",
  "backgroundSources": [
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/question-bank/records/Q-307.json",
      "sha256": "89c6fdc7197675a462a67fa943b9e63c38197a5476b57344fe8674593ea05bd5",
      "locator": "/inputs"
    },
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/cases/records/CASE-015.json",
      "sha256": "3e384abdad97e72866e802ba585f5243df51b3b1950003c6a0b2affe61e921bc",
      "locator": "/studentTask/inputs"
    },
    {
      "path": "courses/gai/knowledge-map/content/nodes/A32.json",
      "sha256": "eeda185e333bcf73f03d2c78d93c7ee86f15916ec411bff55ede2bd00cb5e892",
      "locator": "whole_file"
    },
    {
      "path": "courses/gai/knowledge-map/content/nodes/A34.json",
      "sha256": "67c43c576a8fe7fe4e764c4ddd28d2643fe00b537d28f11489f8eddc2be947c7",
      "locator": "whole_file"
    },
    {
      "path": "courses/gai/knowledge-map/content/nodes/A36.json",
      "sha256": "6925dfaac32b14764f9de8e07a66dc565c55d65e273a82dd688191607a0e1870",
      "locator": "whole_file"
    }
  ]
}
```

## 必要动作

1. 在完整student副本运行controller.cjs，保存原始中断快照和基线恢复输出。
2. 复制policy.json为learner-policy.json，将stopOnMissing改为true，实际运行同一快照。
3. 比较trace/产物/未决项，说明谁应补什么资料。运行test.cjs检查正常输入、停止、重复恢复和原快照不变。

## 提交与自查

提交一张证据单及本任务实际产物，保留原判断、修订、本人/AI贡献和未测范围。

- 配置变化与实际轨迹对应。
- 恢复读取真实产物/未决状态。
- 停止时无新恢复和产物。
- 正常/重复恢复可操作且责任可交接。

四项各0/1，仅作本微任务形成性自查。待补证据登记待补，未执行不能算实际操作通过。课程正式成绩归属由教师另行公布。

## 能力范围

- A32　B07内存产物恢复/重复执行。
- A34　新增可执行缺字段停止配置。
- A36　轨迹及缺地点的人工接管请求，无真实通知/鉴权。

微任务范围对齐当前选编，固定情境为明确标注的课堂构造。

## 副本根目录中的操作入口

以下命令在整个student工作副本根目录执行。保存输出时先保留已有同名文件。注释行是人工编辑要求，不是已完成记录。

```sh
node runtime/u23/controller.cjs runtime/u23/interrupted.json runtime/u23/policy.json baseline-resume > baseline-output.json
cp runtime/u23/policy.json runtime/u23/learner-policy.json
# 用文本编辑器将learner-policy.json的stopOnMissing改true
node runtime/u23/controller.cjs runtime/u23/interrupted.json runtime/u23/learner-policy.json learner-resume > guarded-output.json
node runtime/u23/test.cjs
```

## 概念使用边界

B07与停止包装器是内存模拟，不代表真实系统幂等或鉴权已验证。
