'use strict';
const B07 = require('./b07-core.js');
const input = require('./run-input.json');
(async () => {
 const initial = await B07.makeInitial(input);
 const interrupted = await B07.recover(initial, {attemptId:'classroom-crash', crashAfterJobId:'J12'});
 process.stdout.write(JSON.stringify(interrupted, null, 2) + '\n');
})().catch(error => { process.stderr.write(error.message + '\n'); process.exitCode=1; });
