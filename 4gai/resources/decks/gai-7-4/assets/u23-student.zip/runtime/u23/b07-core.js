'use strict';

class ExecutionError extends Error {
  constructor(code, detail = '') {
    super(detail ? `${code} · ${detail}` : code);
    this.name = 'ExecutionError';
    this.code = code;
  }
}

function requireCondition(condition, code, detail) {
  if (!condition) throw new ExecutionError(code, detail);
}

function object(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function nonempty(value) {
  return typeof value === 'string' && value.trim().length > 0;
}

function canonical(value) {
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
  if (object(value)) return '{' + Object.keys(value).sort().map(key => JSON.stringify(key) + ':' + canonical(value[key])).join(',') + '}';
  return JSON.stringify(value);
}

async function sha256(value) {
  const bytes = new TextEncoder().encode(canonical(value));
  const result = await globalThis.crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(result), byte => byte.toString(16).padStart(2, '0')).join('');
}

function newSession(budget = 12) {
  requireCondition(Number.isInteger(budget) && budget > 0, 'INVALID_BUDGET');
  return { schemaVersion: 1, budget, reads: [], trace: [], artifacts: [] };
}

function validateSession(session, pack) {
  requireCondition(object(session) && session.schemaVersion === 1 && Number.isInteger(session.budget) && session.budget > 0, 'INVALID_SESSION');
  const ids = new Set(pack.documents.map(document => document.id));
  requireCondition(Array.isArray(session.reads) && session.reads.length <= session.budget && session.reads.every(id => ids.has(id)) && Array.isArray(session.trace), 'INVALID_SESSION');
  requireCondition(Object.keys(session).sort().join(',') === 'artifacts,budget,reads,schemaVersion,trace' && Array.isArray(session.artifacts), 'INVALID_SESSION');
  requireCondition(session.trace.every((event, index) => object(event) && event.step === index + 1 && nonempty(event.action) && nonempty(event.result) && Object.keys(event).every(key => ['step', 'action', 'result', 'docId', 'artifactId', 'operation'].includes(key))), 'INVALID_SESSION');
  requireCondition(canonical(session.trace.filter(event => event.action === 'read_document').map(event => event.docId)) === canonical(session.reads), 'INVALID_SESSION');
  const artifactIds = new Set();
  for (const artifact of session.artifacts) {
    validateArtifactRequest(artifact, artifact.workerId);
    requireCondition(Object.keys(artifact).sort().join(',') === 'artifactId,content,path,version,workerId', 'INVALID_SESSION');
    requireCondition(artifact.artifactId === `${artifact.path}@${artifact.version}` && !artifactIds.has(artifact.artifactId), 'INVALID_SESSION');
    artifactIds.add(artifact.artifactId);
  }
}

function validateArtifactRequest(request, activeWorkerId) {
  requireCondition(object(request) && ['W1', 'W2', 'W3'].includes(activeWorkerId) && nonempty(request.workerId) && nonempty(request.path) && /^\d+\.\d+\.\d+$/.test(request.version) && object(request.content), 'INVALID_ARTIFACT_REQUEST');
  requireCondition(request.workerId === activeWorkerId, 'WORKER_SCOPE_DENIED');
  const parts = request.path.split('/');
  requireCondition(parts.length >= 2 && parts[0] === activeWorkerId && parts.every(part => /^[a-zA-Z0-9_.-]+$/.test(part) && !['.', '..'].includes(part)) && request.path.endsWith('.json'), 'WORKER_SCOPE_DENIED');
}

function writeArtifact(session, request, activeWorkerId, pack) {
  validateSession(session, pack);
  validateArtifactRequest(request, activeWorkerId);
  requireCondition(Object.keys(request).sort().join(',') === 'content,path,version,workerId', 'INVALID_ARTIFACT_REQUEST');
  const artifact = { ...structuredClone(request), artifactId: `${request.path}@${request.version}` };
  requireCondition(!session.artifacts.some(item => item.artifactId === artifact.artifactId), 'ARTIFACT_VERSION_EXISTS');
  const next = structuredClone(session);
  next.artifacts.push(artifact);
  next.trace.push({ step: next.trace.length + 1, action: 'write_artifact', artifactId: artifact.artifactId, result: 'local_memory_artifact_written' });
  return { session: next, artifact: structuredClone(artifact) };
}

function validDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = new Date(value + 'T00:00:00Z');
  return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}

function checkDecision(request, decision) {
  requireCondition(object(request) && object(decision) && nonempty(request.requestId) && nonempty(request.candidate) && nonempty(request.objectVersion) && validDate(request.asOf) && request.action === 'external_submit', 'INVALID_DECISION');
  requireCondition(['approve', 'reject'].includes(decision.decision) && nonempty(decision.actor) && nonempty(decision.requestId) && nonempty(decision.candidate) && nonempty(decision.objectVersion) && nonempty(decision.action) && validDate(decision.validUntil), 'INVALID_DECISION');
  if (['requestId', 'candidate', 'objectVersion', 'action'].some(key => request[key] !== decision[key])) return 'decision_scope_mismatch';
  if (decision.validUntil < request.asOf) return 'decision_expired';
  return decision.decision === 'approve' ? 'approval_matched_no_send' : 'decision_rejected';
}

async function exportEvidence(session, handoff, pack) {
  reviewHandoff(handoff, session, pack);
  return { schemaVersion: 1, contextSha256: await sha256(pack), session: structuredClone(session), handoff: structuredClone(handoff) };
}

async function restoreEvidence(payload, pack) {
  requireCondition(object(payload) && payload.schemaVersion === 1 && Object.keys(payload).sort().join(',') === 'contextSha256,handoff,schemaVersion,session', 'INVALID_EVIDENCE_SNAPSHOT');
  requireCondition(payload.contextSha256 === await sha256(pack), 'EVIDENCE_CONTEXT_MISMATCH');
  reviewHandoff(payload.handoff, payload.session, pack);
  return { session: structuredClone(payload.session), handoff: structuredClone(payload.handoff) };
}

function readDocument(session, docId, pack) {
  validateSession(session, pack);
  const document = pack.documents.find(item => item.id === docId);
  requireCondition(document, 'UNKNOWN_DOCUMENT', String(docId));
  requireCondition(session.reads.length < session.budget, 'READ_BUDGET_EXHAUSTED');
  const next = structuredClone(session);
  next.reads.push(docId);
  next.trace.push({ step: next.trace.length + 1, action: 'read_document', docId, result: 'fixed_document_returned' });
  return { session: next, document: structuredClone(document) };
}

function reviewHandoff(payload, session, pack) {
  validateSession(session, pack);
  requireCondition(object(payload) && payload.schemaVersion === 1 && Array.isArray(payload.claims) && payload.claims.length > 0, 'INVALID_HANDOFF');
  const fields = ['annualFee', 'seats', 'csvExport', 'dataLocal'];
  const claims = payload.claims.map((claim, index) => {
    requireCondition(object(claim) && Object.keys(claim).sort().join(',') === 'candidate,field,sourceIds,value', 'INVALID_CLAIM', String(index));
    const quote = pack.quotes.find(item => item.candidate === claim.candidate);
    requireCondition(quote && fields.includes(claim.field), 'INVALID_CLAIM', String(index));
    const validType = ['annualFee', 'seats'].includes(claim.field) ? Number.isFinite(claim.value) && claim.value >= 0 : typeof claim.value === 'boolean' || claim.value === null;
    requireCondition(validType && Array.isArray(claim.sourceIds) && claim.sourceIds.length > 0 && new Set(claim.sourceIds).size === claim.sourceIds.length, 'INVALID_CLAIM', String(index));
    requireCondition(claim.sourceIds.every(id => pack.documents.some(document => document.id === id)), 'UNKNOWN_REFERENCE', String(index));
    const requiredSources = [quote.baseId];
    if (quote.revisionId) requiredSources.push(quote.revisionId);
    const actual = quote[claim.field];
    let status = 'supported';
    if (!claim.sourceIds.every(id => session.reads.includes(id))) status = 'unread_source';
    else if (claim.sourceIds.some(id => !requiredSources.includes(id))) status = 'unsupported_reference';
    else if (!requiredSources.every(id => claim.sourceIds.includes(id))) status = 'incomplete_version_chain';
    else if (actual === null && claim.value !== null) status = 'unknown_asserted_as_fact';
    else if (claim.value !== actual) status = 'contradicted';
    return { index, candidate: claim.candidate, field: claim.field, proposed: claim.value, status, actual, requiredSources };
  });
  const next = structuredClone(session);
  next.trace.push({ step: next.trace.length + 1, action: 'review_handoff', result: claims.every(claim => claim.status === 'supported') ? 'claims_checked' : 'needs_revision' });
  return { session: next, status: claims.every(claim => claim.status === 'supported') ? 'claims_checked' : 'needs_revision', claims, scope: '仅检查已声明命题与固定字段标注。资料覆盖、候选能否采用与外发决定需另行判断。' };
}

function externalSubmit(session, request, decision) {
  requireCondition(object(session) && Array.isArray(session.trace) && object(request) && nonempty(request.candidate), 'INVALID_REQUEST');
  const next = structuredClone(session);
  const result = decision === undefined ? 'approval_required' : checkDecision(request, decision);
  next.trace.push({ step: next.trace.length + 1, action: 'external_submit', result });
  return { session: next, status: result, sent: false };
}

function validateSnapshot(state) {
  requireCondition(object(state) && state.schemaVersion === 1, 'UNSUPPORTED_SNAPSHOT');
  const keys = ['schemaVersion', 'runId', 'rulesVersion', 'jobs', 'checkpoint', 'artifacts', 'temporary', 'quarantine', 'attempts', 'status'];
  requireCondition(Object.keys(state).sort().join(',') === keys.sort().join(',') && nonempty(state.runId) && /^\d+\.\d+\.\d+$/.test(state.rulesVersion), 'INVALID_SNAPSHOT');
  requireCondition(['pending', 'interrupted', 'needs_review', 'completed'].includes(state.status), 'INVALID_SNAPSHOT');
  requireCondition(Array.isArray(state.jobs) && state.jobs.length > 0 && Array.isArray(state.checkpoint) && state.checkpoint.length === state.jobs.length, 'INVALID_SNAPSHOT');
  const ids = new Set();
  for (const job of state.jobs) {
    requireCondition(object(job) && /^J\d{2,}$/.test(job.id) && !ids.has(job.id) && nonempty(job.sourceId) && object(job.source), 'INVALID_JOB');
    requireCondition(Object.keys(job).sort().join(',') === 'id,source,sourceId' && Object.keys(job.source).sort().join(',') === 'place,time,topic', 'INVALID_JOB');
    requireCondition(['topic', 'time', 'place'].every(field => job.source[field] === null || nonempty(job.source[field])), 'INVALID_JOB');
    ids.add(job.id);
  }
  const checkpointIds = new Set();
  for (const row of state.checkpoint) {
    requireCondition(object(row) && ids.has(row.jobId) && !checkpointIds.has(row.jobId) && ['pending', 'running', 'completed', 'blocked'].includes(row.status), 'INVALID_CHECKPOINT');
    requireCondition(Object.keys(row).sort().join(',') === 'artifactKey,artifactSha256,jobId,lastAttemptId,rulesVersion,sourceSha256,status,unresolved', 'INVALID_CHECKPOINT');
    requireCondition((row.sourceSha256 === null || /^[a-f0-9]{64}$/.test(row.sourceSha256)) && /^\d+\.\d+\.\d+$/.test(row.rulesVersion) && (row.lastAttemptId === null || nonempty(row.lastAttemptId)), 'INVALID_CHECKPOINT');
    requireCondition(Array.isArray(row.unresolved) && row.unresolved.every(nonempty) && (row.artifactKey === null || nonempty(row.artifactKey)) && (row.artifactSha256 === null || /^[a-f0-9]{64}$/.test(row.artifactSha256)), 'INVALID_CHECKPOINT');
    checkpointIds.add(row.jobId);
  }
  requireCondition(Array.isArray(state.artifacts) && Array.isArray(state.temporary) && Array.isArray(state.quarantine) && Array.isArray(state.attempts), 'INVALID_SNAPSHOT');
  const artifactKeys = new Set();
  for (const entry of state.artifacts) {
    requireCondition(object(entry) && nonempty(entry.key) && !artifactKeys.has(entry.key) && object(entry.report) && /^[a-f0-9]{64}$/.test(entry.sha256), 'INVALID_ARTIFACT');
    requireCondition(Object.keys(entry).sort().join(',') === 'key,report,sha256' && Object.keys(entry.report).sort().join(',') === 'fields,jobId,rulesVersion,runId,sourceSha256' && ids.has(entry.report.jobId) && object(entry.report.fields), 'INVALID_ARTIFACT');
    requireCondition(nonempty(entry.report.runId) && /^\d+\.\d+\.\d+$/.test(entry.report.rulesVersion) && /^[a-f0-9]{64}$/.test(entry.report.sourceSha256), 'INVALID_ARTIFACT');
    requireCondition(Object.keys(entry.report.fields).sort().join(',') === 'place,time,topic' && Object.values(entry.report.fields).every(value => value === null || nonempty(value)), 'INVALID_ARTIFACT');
    requireCondition(new RegExp('^' + entry.report.jobId + '(?:-[A-Za-z0-9_-]+)?\\.json$').test(entry.key), 'INVALID_ARTIFACT');
    artifactKeys.add(entry.key);
  }
  for (const entry of state.temporary) requireCondition(object(entry) && ids.has(entry.jobId) && nonempty(entry.text) && Object.keys(entry).sort().join(',') === 'jobId,text', 'INVALID_TEMPORARY');
  for (const entry of state.quarantine) requireCondition(object(entry) && Object.keys(entry).sort().join(',') === 'attemptId,kind,original,reason' && ['final_artifact', 'temporary'].includes(entry.kind) && nonempty(entry.attemptId) && nonempty(entry.reason) && object(entry.original), 'INVALID_QUARANTINE');
  const attempts = new Set();
  for (const attempt of state.attempts) {
    requireCondition(object(attempt) && nonempty(attempt.id) && !attempts.has(attempt.id) && Array.isArray(attempt.events) && ['running', 'interrupted', 'finished'].includes(attempt.status), 'INVALID_ATTEMPT');
    requireCondition(Object.keys(attempt).sort().join(',') === 'events,id,status' && attempt.events.every(event => object(event) && ids.has(event.jobId) && nonempty(event.action) && nonempty(event.result)), 'INVALID_ATTEMPT');
    requireCondition(attempt.events.every(event => Object.keys(event).every(key => ['jobId', 'action', 'result', 'key', 'missing'].includes(key)) && (event.key === undefined || nonempty(event.key)) && (event.missing === undefined || Array.isArray(event.missing) && event.missing.every(nonempty))), 'INVALID_ATTEMPT');
    attempts.add(attempt.id);
  }
  requireCondition(state.quarantine.every(entry => attempts.has(entry.attemptId)), 'INVALID_QUARANTINE');
  return state;
}

async function makeInitial(input) {
  requireCondition(object(input) && Array.isArray(input.jobs), 'INVALID_INPUT');
  const state = { schemaVersion: 1, runId: input.runId, rulesVersion: input.rulesVersion, jobs: structuredClone(input.jobs), checkpoint: input.jobs.map(job => ({ jobId: job.id, status: 'pending', sourceSha256: null, rulesVersion: input.rulesVersion, artifactKey: null, artifactSha256: null, lastAttemptId: null, unresolved: [] })), artifacts: [], temporary: [], quarantine: [], attempts: [], status: 'pending' };
  validateSnapshot(state);
  for (const row of state.checkpoint) row.sourceSha256 = await sha256(state.jobs.find(job => job.id === row.jobId));
  return state;
}

async function makeReport(state, job, key) {
  const report = { runId: state.runId, jobId: job.id, rulesVersion: state.rulesVersion, sourceSha256: await sha256(job), fields: structuredClone(job.source) };
  return { key, report, sha256: await sha256(report) };
}

async function inspectRun(state) {
  validateSnapshot(state);
  const artifacts = [];
  for (const entry of state.artifacts) {
    const job = state.jobs.find(item => item.id === entry.report.jobId);
    const hashMatches = await sha256(entry.report) === entry.sha256;
    const identityMatches = entry.report.runId === state.runId && entry.report.rulesVersion === state.rulesVersion && entry.report.sourceSha256 === await sha256(job);
    const fieldsMatch = canonical(entry.report.fields) === canonical(job.source) && Object.values(job.source).every(nonempty);
    artifacts.push({ key: entry.key, jobId: job.id, hashMatches, identityMatches, fieldsMatch, valid: hashMatches && identityMatches && fieldsMatch });
  }
  const jobs = state.jobs.map(job => {
    const valid = artifacts.filter(entry => entry.jobId === job.id && entry.valid);
    const checkpoint = state.checkpoint.find(row => row.jobId === job.id);
    const match = valid.find(entry => entry.key === checkpoint.artifactKey);
    const stored = state.artifacts.find(entry => entry.key === checkpoint.artifactKey);
    const witnessed = state.attempts.some(attempt => attempt.id === checkpoint.lastAttemptId && attempt.events.some(event => {
      const completedAction = ['write_report:written', 'verify_and_reuse:verified'].includes(`${event.action}:${event.result}`);
      return event.jobId === job.id && event.key === checkpoint.artifactKey && completedAction;
    }));
    const checkpointVerified = checkpoint.status === 'completed' && checkpoint.unresolved.length === 0 && witnessed && !!match && stored.sha256 === checkpoint.artifactSha256 && checkpoint.rulesVersion === state.rulesVersion && checkpoint.sourceSha256 === stored.report.sourceSha256;
    return {
      jobId: job.id,
      missing: Object.keys(job.source).filter(field => !nonempty(job.source[field])),
      validArtifacts: valid.map(entry => entry.key),
      duplicate: valid.length > 1,
      checkpointStatus: checkpoint.status,
      checkpointVerified
    };
  });
  return { artifacts, jobs, declaredStatus: state.status, verifiedComplete: jobs.every(job => job.checkpointVerified && !job.duplicate) && artifacts.every(entry => entry.valid) && state.temporary.length === 0 };
}

async function recover(snapshot, options) {
  validateSnapshot(snapshot);
  requireCondition(object(options) && nonempty(options.attemptId), 'INVALID_ATTEMPT');
  requireCondition(!snapshot.attempts.some(attempt => attempt.id === options.attemptId), 'DUPLICATE_ATTEMPT');
  requireCondition(options.crashAfterJobId === undefined || snapshot.jobs.some(job => job.id === options.crashAfterJobId), 'INVALID_FAULT_POINT');
  const next = structuredClone(snapshot);
  const inspected = await inspectRun(next);
  const attempt = { id: options.attemptId, status: 'running', events: [] };
  next.attempts.push(attempt);
  for (const job of next.jobs) {
    const row = next.checkpoint.find(item => item.jobId === job.id);
    const valid = inspected.artifacts.filter(item => item.jobId === job.id && item.valid);
    const reusable = valid.find(item => item.key === `${job.id}.json`) ?? valid[0];
    const redundant = next.artifacts.filter(entry => entry.report.jobId === job.id && entry.key !== reusable?.key);
    for (const entry of redundant) next.quarantine.push({ kind: 'final_artifact', attemptId: options.attemptId, reason: 'invalid_or_duplicate', original: entry });
    next.artifacts = next.artifacts.filter(entry => entry.report.jobId !== job.id || entry.key === reusable?.key);
    for (const entry of next.temporary.filter(entry => entry.jobId === job.id)) next.quarantine.push({ kind: 'temporary', attemptId: options.attemptId, reason: 'unfinished_input', original: entry });
    next.temporary = next.temporary.filter(entry => entry.jobId !== job.id);
    const missing = Object.keys(job.source).filter(field => !nonempty(job.source[field]));
    row.sourceSha256 = await sha256(job);
    row.rulesVersion = next.rulesVersion;
    row.lastAttemptId = options.attemptId;
    row.unresolved = missing;
    if (missing.length) {
      Object.assign(row, { status: 'blocked', artifactKey: null, artifactSha256: null });
      attempt.events.push({ jobId: job.id, action: 'handoff', result: 'blocked', missing });
      continue;
    }
    let artifact = reusable && next.artifacts.find(entry => entry.key === reusable.key);
    if (!artifact) {
      row.status = 'running';
      artifact = await makeReport(next, job, `${job.id}.json`);
      next.artifacts.push(artifact);
      attempt.events.push({ jobId: job.id, action: 'write_report', result: 'written', key: artifact.key });
      if (options.crashAfterJobId === job.id) {
        attempt.events.push({ jobId: job.id, action: 'fault_injection', result: 'after_report_before_checkpoint' });
        attempt.status = 'interrupted';
        next.status = 'interrupted';
        return next;
      }
    } else attempt.events.push({ jobId: job.id, action: 'verify_and_reuse', result: 'verified', key: artifact.key });
    Object.assign(row, { status: 'completed', artifactKey: artifact.key, artifactSha256: artifact.sha256 });
  }
  attempt.status = 'finished';
  next.status = (await inspectRun(next)).verifiedComplete ? 'completed' : 'needs_review';
  return next;
}

async function makeInterrupted(input) {
  const state = await makeInitial(input);
  const job = state.jobs.find(item => item.id === 'J03');
  if (job) state.temporary.push({ jobId: job.id, text: '课堂预置未完成暂存件。该文本不代表审核完成。' });
  return recover(state, { attemptId: 'attempt-initial', crashAfterJobId: 'J02' });
}

function restoreSnapshot(payload) {
  validateSnapshot(payload);
  return structuredClone(payload);
}

const B07 = { ExecutionError, canonical, sha256, newSession, readDocument, reviewHandoff, writeArtifact, checkDecision, exportEvidence, restoreEvidence, externalSubmit, validateSnapshot, makeInitial, makeReport, inspectRun, recover, makeInterrupted, restoreSnapshot };
if (typeof module !== 'undefined' && module.exports) module.exports = B07;
else globalThis.B07 = B07;
