'use strict';
const fs = require('node:fs');
const path = require('node:path');
const B07 = require('./b07-core.js');
async function run(snapshot, policy, attemptId) {
 B07.validateSnapshot(snapshot);
 if (!policy || typeof policy.stopOnMissing !== 'boolean' || typeof policy.owner !== 'string' || !policy.owner.trim()) throw new Error('INVALID_POLICY');
 const pending = snapshot.jobs.flatMap(job => Object.entries(job.source)
  .filter(([,value]) => typeof value !== 'string' || !value.trim())
  .map(([field]) => ({jobId:job.id, field, owner:policy.owner})));
 if (policy.stopOnMissing && pending.length) {
  return {controllerStatus:'takeover_pending', pending, snapshot:structuredClone(snapshot), trace:[{action:'request_takeover', result:'no_recover_called'}]};
 }
 const next = await B07.recover(snapshot, {attemptId});
 return {controllerStatus:next.status, pending, snapshot:next, trace:[{action:'recover', result:next.status}]};
}
if (require.main === module) {
 (async () => {
  const snapshot = JSON.parse(fs.readFileSync(process.argv[2] || path.join(__dirname, 'interrupted.json'), 'utf8'));
  const policy = JSON.parse(fs.readFileSync(process.argv[3] || path.join(__dirname, 'policy.json'), 'utf8'));
  const result = await run(snapshot, policy, process.argv[4] || 'student-resume');
  process.stdout.write(JSON.stringify(result, null, 2) + '\n');
 })().catch(error => { process.stderr.write(error.message + '\n'); process.exitCode = 1; });
}
module.exports = {run};
