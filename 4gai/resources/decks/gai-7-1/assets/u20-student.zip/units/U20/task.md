# U20 选择工作流或Agent并限定工具

候选形成性练习。建议30分钟，学生耗时尚未验证。仅提交本页微任务，不承接可选整题的完整交付或100分量规。

## 固定材料

读取本目录input.json。以下内容可打印使用。

```json
{
  "task": "虚构青禾书店每周汇总固定订单表和异常单，只给内部草稿。订单行字段固定，遇未知状态交值班经理。",
  "alternatives": [
    "确定性校验→汇总→人工确认",
    "让Agent自行规划并调用所有系统"
  ],
  "tools": [
    {
      "name": "read_orders",
      "parameters": [
        "dateRange"
      ],
      "output": "只读固定订单表",
      "allowed": "本周订单",
      "reject": "跨周或其他店铺"
    },
    {
      "name": "draft_summary",
      "parameters": [
        "validatedRows"
      ],
      "output": "内存摘要草稿",
      "allowed": "已核行",
      "reject": "含未知状态行自动发布"
    }
  ],
  "humanAuthority": "值班经理确认对外发布。本次只设计，不调用真实系统。",
  "provenance": "teaching_construct",
  "backgroundSources": [
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/question-bank/records/Q-302.json",
      "sha256": "f5b878cd1be8becf17299e5b61c1be8d6d61fa53ca96ced69133cb18eded3d97",
      "locator": "/inputs"
    },
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/cases/records/CASE-014.json",
      "sha256": "4289bd30382ce0d235e3b604b145efc07a0b63c4b8328eb3108b4d322ad990c4",
      "locator": "/studentTask/inputs"
    },
    {
      "path": "courses/gai/knowledge-map/content/nodes/A30.json",
      "sha256": "c3bea461ed283c196b4757411801a00f6c7d503e037fba72f9df12db25f014d3",
      "locator": "whole_file"
    },
    {
      "path": "courses/gai/knowledge-map/content/nodes/A31.json",
      "sha256": "ce02cfdfc5f491dc02911aa8e883124977905155259b683d16adb0fd19131bc8",
      "locator": "whole_file"
    }
  ]
}
```

## 必要动作

1. 按给定固定字段/异常说明比较两流程，不把自动化范围扩大。
2. 写两个工具的参数、输出、允许动作、拒绝条件和人工发布点。
3. 指出固定流程足够或自主决策有必要的证据，保留替代方案。

## 提交与自查

提交一张证据单及本任务实际产物，保留原判断、修订、本人/AI贡献和未测范围。

- 选择对应稳定性/风险。
- 工具参数输出完整。
- 越权/无效输入有拒绝。
- 成功返回不代替授权。

四项各0/1，仅作本微任务形成性自查。待补证据登记待补，未执行不能算实际操作通过。课程正式成绩归属由教师另行公布。

## 能力范围

- A30　纸面接口/最小权限设计。
- A31　固定与自主流程选择说明。

微任务范围对齐当前选编，固定情境为明确标注的课堂构造。

## 概念使用边界

只支持固定卡中的相关解释，不登记整个概念或能力达成。
