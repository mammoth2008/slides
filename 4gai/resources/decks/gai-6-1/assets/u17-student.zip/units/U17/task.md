# U17 从需求到可运行起点

候选形成性练习。建议30分钟，学生耗时尚未验证。仅提交本页微任务，不承接可选整题的完整交付或100分量规。

## 固定材料

读取本目录input.json。以下内容可打印使用。

```json
{
  "runtime": "../../runtime/b06/core.js",
  "field": "averageMinutesPerRecordedDay",
  "contract": [
    "真实日期YYYY-MM-DD，分钟整数0..1440，先校验所有行再按闭区间筛选。",
    "日均分母为范围内有记录的不同日期，0分钟日也计入。空集总0日均null。",
    "start>end报告INVALID_RANGE。"
  ],
  "input": {
    "schemaVersion": 1,
    "range": {
      "start": "2026-10-01",
      "end": "2026-10-04"
    },
    "records": [
      {
        "id": "s1",
        "date": "2026-10-01",
        "minutes": 30
      },
      {
        "id": "s2",
        "date": "2026-10-01",
        "minutes": 10
      },
      {
        "id": "s3",
        "date": "2026-10-04",
        "minutes": 0
      }
    ]
  },
  "provenance": "teaching_construct",
  "backgroundSources": [
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/question-bank/records/Q-201.json",
      "sha256": "9dedde304f3fb71bb5d3b33f13a3a8bb57493614edea8c9d53eded00b5804ed7",
      "locator": "/inputs"
    },
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/cases/records/CASE-003.json",
      "sha256": "652232e75402962e109c034511c3e73f73d3522e2685097634160c4511ae320f",
      "locator": "/studentTask/inputs"
    },
    {
      "path": "courses/gai/knowledge-map/content/nodes/A26.json",
      "sha256": "41af701b96aa1d053b19f2a645f531537527db7312d09692203174aa03b87d08",
      "locator": "whole_file"
    }
  ]
}
```

## 必要动作

1. 运行node runtime/b06/run.cjs，读取specExample和baseline/reference。
2. 只围绕日均字段写输入类型/空集/错误/验收例规格。
3. 给同伴能重复运行的起点路径与命令，不要求自行设计全应用。

## 提交与自查

提交一张证据单及本任务实际产物，保留原判断、修订、本人/AI贡献和未测范围。

- 字段输入输出定义明确。
- 空集与0分钟不混同。
- 错误行为有例。
- 真实运行起点和输出可回查。

四项各0/1，仅作本微任务形成性自查。待补证据登记待补，未执行不能算实际操作通过。课程正式成绩归属由教师另行公布。

## 能力范围

- A26　日均字段的规格/验收例，非全应用。

微任务范围对齐当前选编，固定情境为明确标注的课堂构造。

## 副本根目录中的操作入口

以下命令在整个student工作副本根目录执行。保存输出时先保留已有同名文件。注释行是人工编辑要求，不是已完成记录。

```sh
node --version
node runtime/b06/run.cjs
```

## 概念使用边界

只支持固定卡中的相关解释，不登记整个概念或能力达成。
