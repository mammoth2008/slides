globalThis.B06Fixtures = {
  "statistics": {
    "schemaVersion": 1,
    "range": {
      "start": "2026-10-01",
      "end": "2026-10-03"
    },
    "records": [
      {
        "id": "r1",
        "date": "2026-10-01",
        "minutes": 30
      },
      {
        "id": "r2",
        "date": "2026-10-02",
        "minutes": 45
      },
      {
        "id": "r3",
        "date": "2026-10-03",
        "minutes": 15
      },
      {
        "id": "r4",
        "date": "2026-09-30",
        "minutes": 20
      },
      {
        "id": "r5",
        "date": "2026-10-02",
        "minutes": -5
      },
      {
        "id": "r6",
        "date": "2026-10-02",
        "minutes": "20"
      },
      {
        "id": "r7",
        "date": "2026-10-04",
        "minutes": 90
      }
    ]
  },
  "legacy": {
    "schemaVersion": 1,
    "records": [
      {
        "id": "a1",
        "date": "2026-10-01",
        "minutes": 30
      },
      {
        "id": "a2",
        "date": "2026-10-02",
        "minutes": 45
      }
    ]
  },
  "next": {
    "schemaVersion": 2,
    "records": [
      {
        "id": "b1",
        "date": "2026-10-03",
        "durationMinutes": 15
      }
    ]
  },
  "failing": {
    "schemaVersion": 2,
    "records": [
      {
        "id": "b2",
        "date": "2026-10-04",
        "durationMinutes": 20
      },
      {
        "id": "b3",
        "date": "2026-10-04",
        "durationMinutes": -5
      }
    ]
  },
  "unknown": {
    "schemaVersion": 99,
    "records": []
  }
};
if (typeof module !== "undefined" && module.exports) module.exports = globalThis.B06Fixtures;
