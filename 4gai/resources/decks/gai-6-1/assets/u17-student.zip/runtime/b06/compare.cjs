'use strict';
const A = require('./patch-a.cjs');
const B = require('./patch-b.cjs');
const cases = [
 {name:'dense', input:{schemaVersion:1, range:{start:'2026-10-01',end:'2026-10-03'}, records:[{id:'d1',date:'2026-10-01',minutes:30},{id:'d2',date:'2026-10-02',minutes:45},{id:'d3',date:'2026-10-03',minutes:15}]}},
 {name:'gap', input:{schemaVersion:1, range:{start:'2026-10-01',end:'2026-10-04'}, records:[{id:'g1',date:'2026-10-01',minutes:30},{id:'g2',date:'2026-10-04',minutes:30}]}}
];
for (const item of cases) console.log(JSON.stringify({name:item.name, A:A.summarize(item.input), B:B.summarize(item.input)}));
