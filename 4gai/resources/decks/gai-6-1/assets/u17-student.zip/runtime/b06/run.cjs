'use strict';
const fs = require('node:fs');
const path = require('node:path');
const input = JSON.parse(fs.readFileSync(path.join(__dirname, '../../units/U17/input.json'), 'utf8')).input;
const core = require('./core.js');
const baseline = require('./boundary-candidate.js');
const fixture = require('./fixtures.js').statistics;
console.log(JSON.stringify({specExample: core.summarize(input), baseline: baseline.summarize(fixture), reference: core.summarize(fixture)}, null, 2));
