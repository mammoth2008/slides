/* Course-constructed business rules. Runs in a browser and in Node. */
'use strict';
class DomainError extends Error {
  constructor(code, id = null, index = null) {
    super(code);
    this.name = 'DomainError';
    this.code = code;
    this.id = id;
    this.index = index;
  }
}
function isDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(value + 'T00:00:00.000Z');
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}
function normalizeRecord(record, field, index) {
  if (!record || typeof record !== 'object' || Array.isArray(record)) throw new DomainError('INVALID_RECORD', null, index);
  const id = typeof record.id === 'string' && record.id.trim() ? record.id : null;
  if (!id || Object.keys(record).sort().join(',') !== ['id', 'date', field].sort().join(',')) throw new DomainError('INVALID_RECORD', id, index);
  if (!isDate(record.date)) throw new DomainError('INVALID_DATE', id, index);
  if (!Number.isInteger(record[field]) || record[field] < 0 || record[field] > 1440) throw new DomainError('INVALID_MINUTES', id, index);
  return {id, date: record.date, minutes: record[field]};
}
function checkPackage(payload) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) throw new DomainError('INVALID_PACKAGE');
  if (![1, 2].includes(payload.schemaVersion)) throw new DomainError('UNSUPPORTED_SCHEMA');
  if (!Array.isArray(payload.records)) throw new DomainError('INVALID_PACKAGE');
}
function summarize(payload) {
  checkPackage(payload);
  if (payload.schemaVersion !== 1) throw new DomainError('UNSUPPORTED_SCHEMA');
  const range = payload.range;
  if (!range || !isDate(range.start) || !isDate(range.end)) throw new DomainError('INVALID_DATE');
  if (range.start > range.end) throw new DomainError('INVALID_RANGE');
  const validRecords = [], invalidRecords = [];
  // Validation precedes filtering, including records outside the selected range.
  payload.records.forEach((row, index) => {
    try { validRecords.push(normalizeRecord(row, 'minutes', index)); }
    catch (error) {
      if (!(error instanceof DomainError)) throw error;
      invalidRecords.push({id: error.id, code: error.code, index});
    }
  });
  const selected = validRecords.filter(row => row.date >= range.start && row.date <= range.end);
  const totalMinutes = selected.reduce((sum, row) => sum + row.minutes, 0);
  const days = new Set(selected.map(row => row.date)).size;
  return {
    validRecords, validRecordCount: validRecords.length,
    selectedIds: selected.map(row => row.id), selectedRecordCount: selected.length,
    totalMinutes, averageMinutesPerRecordedDay: days ? totalMinutes / days : null,
    invalidRecords, display: selected.length ? `${totalMinutes} 分钟` : '无记录'
  };
}
function importRecords(existing, payload) {
  if (!Array.isArray(existing)) throw new DomainError('INVALID_STATE');
  checkPackage(payload);
  const seen = new Set();
  const baseline = existing.map((row, index) => {
    const item = normalizeRecord(row, 'minutes', index);
    if (seen.has(item.id)) throw new DomainError('DUPLICATE_ID', item.id, index);
    seen.add(item.id);
    return item;
  });
  const field = payload.schemaVersion === 1 ? 'minutes' : 'durationMinutes';
  // Stage all rows before returning a new state. Failure leaves existing untouched.
  const staged = payload.records.map((row, index) => {
    const item = normalizeRecord(row, field, index);
    if (seen.has(item.id)) throw new DomainError('DUPLICATE_ID', item.id, index);
    seen.add(item.id);
    return item;
  });
  return baseline.concat(staged);
}
const B06 = {DomainError, isDate, summarize, importRecords};
if (typeof module !== 'undefined' && module.exports) module.exports = B06;
else globalThis.B06 = B06;
