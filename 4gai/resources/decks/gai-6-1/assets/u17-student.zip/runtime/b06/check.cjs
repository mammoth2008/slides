'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const api = require(path.resolve(process.argv[2] || path.join(__dirname, 'core.js')));
const tests = JSON.parse(fs.readFileSync(path.join(__dirname, 'tests.json'), 'utf8'));
let failed = 0;
for (const test of tests) {
 try {
  const actual = api.summarize(test.input);
  assert.equal(actual.totalMinutes, test.expectedTotal);
  if ('expectedAverage' in test) assert.equal(actual.averageMinutesPerRecordedDay, test.expectedAverage);
  if ('expectedCount' in test) assert.equal(actual.selectedRecordCount, test.expectedCount);
  assert.deepEqual(actual.invalidRecords.map(row => row.code), test.expectedInvalid);
  console.log(JSON.stringify({name:test.name, status:'PASS', actual}));
 } catch (error) { failed++; console.log(JSON.stringify({name:test.name, status:'FAIL', error:error.message})); }
}
process.exitCode = failed ? 1 : 0;
