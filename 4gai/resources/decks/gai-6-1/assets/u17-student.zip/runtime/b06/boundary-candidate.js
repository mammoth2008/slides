/* Deliberately defective teaching copy. Preserve this file as the failure baseline. */
(function () {
  const core = typeof module !== 'undefined' && module.exports ? require('./core.js') : globalThis.B06;
  function summarize(payload) {
    const result = core.summarize(payload);
    // Deliberate defect: the agreed end day is omitted.
    const selected = result.validRecords.filter(row => row.date >= payload.range.start && row.date < payload.range.end);
    const total = selected.reduce((sum, row) => sum + row.minutes, 0);
    const days = new Set(selected.map(row => row.date)).size;
    return {...result, selectedIds:selected.map(row => row.id), selectedRecordCount:selected.length,
      totalMinutes:total, averageMinutesPerRecordedDay:days ? total/days : null,
      display:selected.length ? `${total} 分钟` : '无记录'};
  }
  const api = {summarize};
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else globalThis.B06BoundaryCandidate = api;
})();
