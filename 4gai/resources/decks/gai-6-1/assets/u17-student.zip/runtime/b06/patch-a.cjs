const core = require('./core.js');
exports.summarize = input => core.summarize(input);
