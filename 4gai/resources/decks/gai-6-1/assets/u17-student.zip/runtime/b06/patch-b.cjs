const core = require('./core.js');
exports.summarize = input => {
  const result = core.summarize(input);
  const days = (Date.parse(input.range.end) - Date.parse(input.range.start)) / 86400000 + 1;
  return {...result, averageMinutesPerRecordedDay: result.selectedRecordCount ? result.totalMinutes / days : null};
};
