# U16 整合声音画面并形成发布说明

候选形成性练习。建议30分钟，学生耗时尚未验证。仅提交本页微任务，不承接可选整题的完整交付或100分量规。

## 固定材料

读取本目录input.json。以下内容可打印使用。

```json
{
  "assetIds": [
    "VID-001",
    "VID-002",
    "AUD-002"
  ],
  "events": {
    "picture": [
      2,
      6,
      10
    ],
    "offsetSound": [
      2.4,
      6.4,
      10.4
    ]
  },
  "durationSeconds": 12,
  "fps": 25,
  "sampleRate": 48000,
  "classroomToleranceSeconds": 0.08,
  "brief": "程序校准片含纯音，无真实人声。本微任务要求定位偏移并列一次修订方案和素材说明。实际导出为可选扩展，若执行必须保存真实命令/返回/开中末复核。",
  "rights": "课程自制画面与纯音，可用于课堂修改。不是生成视频/真人音频，也不支持人类感知阈值推论。",
  "ffmpegOptional": "ffmpeg -n -i offset.mp4 -i offset.wav -filter_complex \"[1:a]atrim=start=0.4,asetpts=PTS-STARTPTS,apad=pad_dur=0.4,atrim=duration=12[a]\" -map 0:v:0 -map \"[a]\" -c:v copy -c:a aac repaired.mp4",
  "captionNote": "外置captions.vtt仍需独立核查，本命令不把字幕封入MP4。已有FFmpeg者在副本执行，缺工具不临时安装。",
  "provenance": "identified_source_excerpt_and_teaching_construct",
  "backgroundSources": [
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/question-bank/records/Q-146.json",
      "sha256": "d91f181f487d88bbaca25c8024d106fb49099348da3d43aea791d976b750e040",
      "locator": "/inputs"
    },
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/cases/records/CASE-011.json",
      "sha256": "f33634ac38399aa162e03ca86bb9035c77e470516400862147ef068346f71510",
      "locator": "/studentTask/inputs"
    },
    {
      "path": "courses/gai/knowledge-map/content/nodes/A24.json",
      "sha256": "2b24e6a5df179f7d001449abb44d0e70d51d542fd0484f76c81601683a7a1de0",
      "locator": "whole_file"
    },
    {
      "path": "courses/gai/knowledge-map/content/nodes/A25.json",
      "sha256": "8b2cbdac0977f5ad89e64b615a5675f01d631b29ff2a6dff8b3d3cf7432bb70d",
      "locator": "whole_file"
    }
  ]
}
```

实际文件见以下清单。媒体为原字节副本。替代文字只支持相应的文字判断，不充作本人视听证据。

- [VID-001](../../media/b05-sync-lab/originals/reference.mp4)
- [VID-002](../../media/b05-sync-lab/originals/offset.mp4)
- [AUD-002](../../media/b05-sync-lab/originals/offset.wav)

## 必要动作

1. 打开校准片/音轨，或按给定事件表定位三个0.4秒偏移。
2. 交同一版本开中末检查表及一次修订方案，分别标实际试听与纸面计算。
3. 列程序构造来源、外置字幕与发布说明。若另行实际导出，保存命令/返回/成片复查，不把方案记作成片。

## 提交与自查

提交一张证据单及本任务实际产物，保留原判断、修订、本人/AI贡献和未测范围。

- 三事件偏移口径一致。
- 纸面方案/实际操作分别记。
- 同一版本开中末检查。
- 来源/纯音/字幕/标识准确。

四项各0/1，仅作本微任务形成性自查。待补证据登记待补，未执行不能算实际操作通过。课程正式成绩归属由教师另行公布。

## 能力范围

- A24　校准片同步检查，实际导出可选，不能据纸面得实际导出证据。
- A25　自制画面纯音/外置字幕来源说明。

实际修订与纸面方案分别记，本微任务不强制完整导出。

可选导出者将media/b05-sync-lab/originals/中的offset.mp4、offset.wav、captions.vtt复制到新的工作目录，在该目录执行input.json给出的命令。先执行ffmpeg -version确认已有工具，缺工具保持未导出，不要求安装。

## 概念使用边界

纯音程序校准，深度伪造只作素材边界讨论。
