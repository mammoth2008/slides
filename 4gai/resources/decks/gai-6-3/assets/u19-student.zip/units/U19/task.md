# U19 测试回归和独立交接

候选形成性练习。建议30分钟，学生耗时尚未验证。仅提交本页微任务，不承接可选整题的完整交付或100分量规。

## 固定材料

读取本目录input.json。以下内容可打印使用。

```json
{
  "runtime": "../../runtime/b06/",
  "baseline": "boundary-candidate.js保留故意缺陷，不能覆盖",
  "learnerEntry": "learner-candidate.cjs，继承U18实际副本，或按U18公开最小修订重新接入并标注",
  "tests": [
    {
      "name": "normal",
      "input": {
        "schemaVersion": 1,
        "range": {
          "start": "2026-10-01",
          "end": "2026-10-03"
        },
        "records": [
          {
            "id": "n",
            "date": "2026-10-02",
            "minutes": 10
          }
        ]
      },
      "expectedTotal": 10,
      "expectedInvalid": []
    },
    {
      "name": "single-zero",
      "input": {
        "schemaVersion": 1,
        "range": {
          "start": "2026-10-01",
          "end": "2026-10-01"
        },
        "records": [
          {
            "id": "z",
            "date": "2026-10-01",
            "minutes": 0
          }
        ]
      },
      "expectedTotal": 0,
      "expectedAverage": 0,
      "expectedCount": 1,
      "expectedInvalid": []
    },
    {
      "name": "invalid-outside",
      "input": {
        "schemaVersion": 1,
        "range": {
          "start": "2026-10-01",
          "end": "2026-10-03"
        },
        "records": [
          {
            "id": "bad",
            "date": "2026-02-30",
            "minutes": 10
          }
        ]
      },
      "expectedTotal": 0,
      "expectedAverage": null,
      "expectedCount": 0,
      "expectedInvalid": [
        "INVALID_DATE"
      ]
    }
  ],
  "handoff": "另建目录复制core.js、learner-candidate.cjs、tests.json和check.cjs，记录Node版本/文件SHA和逐项返回。此单元采用自己的修订副本，原Q204禁止修改被测对象的整题要求不继承。",
  "provenance": "teaching_construct",
  "backgroundSources": [
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/question-bank/records/Q-204.json",
      "sha256": "547471f8e0b6de8e74655e15677820dcf27b29e71e56246d02bef12be046d2d3",
      "locator": "/inputs"
    },
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/cases/records/CASE-013.json",
      "sha256": "d2cc4bc23af40d832efdeb761b3f2fe37fd522698a3a7ac0435526e31d98c327",
      "locator": "/studentTask/inputs"
    },
    {
      "path": "courses/gai/knowledge-map/content/nodes/A28.json",
      "sha256": "41c586b4da7299b3ba9681ced62600cdfd198c9290f7523f5057c865febba5b0",
      "locator": "whole_file"
    },
    {
      "path": "courses/gai/knowledge-map/content/nodes/A29.json",
      "sha256": "86d4cbbada630f0f63f9693caedeb5aab2f1c21d4aef6d53b53ce0ee72eb2cd9",
      "locator": "whole_file"
    }
  ]
}
```

## 必要动作

1. 继承U18修订副本，没有该副本者按U18公开修订重新接入并说明。
2. 运行三条已给测试，再新增一条1440或1441分钟完整输入及预期并实际运行。
3. 在第二目录复制依赖、测试与修订模块复跑，交Node版本/文件摘要/逐项返回和未测项。

## 提交与自查

提交一张证据单及本任务实际产物，保留原判断、修订、本人/AI贡献和未测范围。

- 正常边界非法逐项实际返回。
- 本人新增用例有执行前预期。
- 第二目录复跑及依赖版本可回查。
- 失败与未测项如实保留。

四项各0/1，仅作本微任务形成性自查。待补证据登记待补，未执行不能算实际操作通过。课程正式成绩归属由教师另行公布。

## 能力范围

- A28　小型统计模块测试/回归。
- A29　单次独立目录复跑和依赖/摘要记录。

微任务范围对齐当前选编，固定情境为明确标注的课堂构造。

## 副本根目录中的操作入口

以下命令在整个student工作副本根目录执行。保存输出时先保留已有同名文件。注释行是人工编辑要求，不是已完成记录。

```sh
node runtime/b06/check.cjs runtime/b06/learner-candidate.cjs
# 新增tests.json副本中的1440或1441用例后重跑。另建目录复制四文件后运行
node check.cjs ./learner-candidate.cjs
```

## 概念使用边界

只支持固定卡中的相关解释，不登记整个概念或能力达成。
