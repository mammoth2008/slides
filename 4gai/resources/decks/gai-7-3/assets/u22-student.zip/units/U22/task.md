# U22 把经验写成可复用Skill

候选形成性练习。建议30分钟，学生耗时尚未验证。仅提交本页微任务，不承接可选整题的完整交付或100分量规。

## 固定材料

读取本目录input.json。以下内容可打印使用。

```json
{
  "completedHandoff": {
    "task": "虚构青禾书店只读报表草稿",
    "version": "0.1",
    "steps": [
      {
        "action": "读取D1",
        "evidence": "D1第1行合计10条构造订单"
      },
      {
        "action": "检查D2",
        "evidence": "D2第2行有2条状态未知"
      },
      {
        "action": "输出草稿",
        "evidence": "草稿明确8条已核、2条待核，未外发，交值班经理"
      }
    ],
    "conditions": "同一店铺、公开汇总、字段规则v1，无外发授权"
  },
  "newInput": {
    "task": "另一周同店草稿",
    "version": "0.2",
    "D1": "第1行合计12条构造订单",
    "D2": "第2行有3条状态未知",
    "rulesVersion": "v1",
    "externalSendApproval": false
  },
  "trap": "把原10、8、2直接写死成Skill所有新任务结果。",
  "outputsBoundary": "交一个小Skill文本和新输入手动迁移轨迹即可，不要求安装Skill平台或运行真实Agent。",
  "provenance": "teaching_construct",
  "backgroundSources": [
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/question-bank/records/Q-305.json",
      "sha256": "3127e7424ce8677bd0a047389cc853289640eab4781312521a0dc36b19005c42",
      "locator": "/inputs"
    },
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/cases/records/CASE-014.json",
      "sha256": "4289bd30382ce0d235e3b604b145efc07a0b63c4b8328eb3108b4d322ad990c4",
      "locator": "/studentTask/inputs"
    },
    {
      "path": "courses/gai/knowledge-map/content/nodes/A33.json",
      "sha256": "d057d43f7c1b123d4067d1ca057b58eaabdcd78511b07aa8020fa7dab72db677",
      "locator": "whole_file"
    }
  ]
}
```

## 必要动作

1. 从已完成交接写一个可发现Skill文本，含用途、输入、步骤、检查、停止条件和来源。
2. 用新输入手动逐步迁移，记录12/3等新值与原记录差异。
3. 判断何时不可复用，不把纸面迁移写成已安装或执行真实Agent。

## 提交与自查

提交一张证据单及本任务实际产物，保留原判断、修订、本人/AI贡献和未测范围。

- 步骤/条件可执行。
- 来源证据保留。
- 新输入迁移非硬编码。
- 停止或调整边界明确。

四项各0/1，仅作本微任务形成性自查。待补证据登记待补，未执行不能算实际操作通过。课程正式成绩归属由教师另行公布。

## 能力范围

- A33　小Skill文本及纸面迁移，不证明平台安装或Agent调用。

微任务范围对齐当前选编，固定情境为明确标注的课堂构造。

## 概念使用边界

只支持固定卡中的相关解释，不登记整个概念或能力达成。
