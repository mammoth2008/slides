# U13 把文本和视觉组织为分镜

候选形成性练习。建议30分钟，学生耗时尚未验证。仅提交本页微任务，不承接可选整题的完整交付或100分量规。

## 固定材料

读取本目录input.json。以下内容可打印使用。

```json
{
  "durationSeconds": 12,
  "requiredMessages": [
    "核对编号",
    "确认归还时间",
    "保存回执"
  ],
  "shots": [
    {
      "id": "S1",
      "plannedSeconds": 3,
      "voiceReadSeconds": 4
    },
    {
      "id": "S2",
      "plannedSeconds": 5,
      "voiceReadSeconds": 6
    },
    {
      "id": "S3",
      "plannedSeconds": 4,
      "voiceReadSeconds": 4
    }
  ],
  "rules": [
    "三句依次完整播放，不重叠。不能把14秒塞进12秒并截断。",
    "可删解释性赘语与改写后再试读，必要信息不得删。未实际重读只交计划，不能写已验证可懂。"
  ],
  "draftExtra": "“每一步都很重要，请大家认真注意”是允许删掉的解释性文字，不属于三条必要信息。",
  "provenance": "teaching_construct",
  "backgroundSources": [
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/question-bank/records/Q-141.json",
      "sha256": "91e1ab118e027a29ed4773399db87b49531df0d76de66ee1332130c9d7bc630d",
      "locator": "/inputs"
    },
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/cases/records/CASE-010.json",
      "sha256": "18fcec642af7fe94824faaf3caa3880d7f9e418095502aff9d677e748c632cb7",
      "locator": "/studentTask/inputs"
    },
    {
      "path": "courses/gai/knowledge-map/content/nodes/A23.json",
      "sha256": "94ccf543d4aa03d6a6b5576ca8ad7d6099b57d6a3ae8842b2e2ce9518807df9b",
      "locator": "whole_file"
    }
  ]
}
```

## 必要动作

1. 把必要信息与镜头、旁白、画面映射到一张12秒时间表。
2. 用给定试读14秒指出冲突，删解释赘语或写改写方案，不能删三条必要信息。
3. 给出重新试读计划，未重读不声称改稿已可懂。

## 提交与自查

提交一张证据单及本任务实际产物，保留原判断、修订、本人/AI贡献和未测范围。

- 三条必要信息均在时间段。
- 12/14秒冲突正确。
- 删减不损必要信息。
- 未测理解/试读保持待测。

四项各0/1，仅作本微任务形成性自查。待补证据登记待补，未执行不能算实际操作通过。课程正式成绩归属由教师另行公布。

## 能力范围

- A23　固定12秒分镜/脚本组织，无成片传播效果。

微任务范围对齐当前选编，固定情境为明确标注的课堂构造。

## 概念使用边界

只支持固定卡中的相关解释，不登记整个概念或能力达成。
