# U18 有依据地实现与审查补丁

候选形成性练习。建议30分钟，学生耗时尚未验证。仅提交本页微任务，不承接可选整题的完整交付或100分量规。

## 固定材料

读取本目录input.json。以下内容可打印使用。

```json
{
  "runtime": "../../runtime/b06/",
  "defectFile": "boundary-candidate.js",
  "modificationFile": "learner-candidate.cjs",
  "fixture": "../../runtime/b06/fixtures.js statistics",
  "contract": "结束日包含，其余口径沿core.js。先复制故意缺陷文件到learner-candidate.cjs，只在副本把结束日<改<=。",
  "comparison": "patch-a.cjs复用正确core，patch-b.cjs将日均分母改为日历天数。按dense/gap反例比较，不以单一例通过裁决。",
  "baselineExpectedTotal": 75,
  "afterExpectedTotal": 90,
  "interpretation": "两个补丁和缺陷均为课堂构造，未调用AI。A27只练实际修改/解释，不宣称亲自生成AI代码。",
  "provenance": "teaching_construct",
  "backgroundSources": [
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/question-bank/records/Q-203.json",
      "sha256": "db4713a476027dde2076b7767ebf917f7e28bb5ca3c65cd52df8771af6569da6",
      "locator": "/inputs"
    },
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/cases/records/CASE-012.json",
      "sha256": "69290857ebf5f9d17e61a91f777c5aef4b19b362ec96353fd36700fc56e6c85b",
      "locator": "/studentTask/inputs"
    },
    {
      "path": "courses/gai/knowledge-map/content/nodes/A27.json",
      "sha256": "3d1b93fa522245078d0128d8c28293832c5fafab46377e5cef44f6a5bb8d25f6",
      "locator": "whole_file"
    }
  ]
}
```

## 必要动作

1. 在完整student副本运行B06 baseline并记录结束日遗漏75。
2. 复制boundary-candidate.js为learner-candidate.cjs，实际修改结束日比较，运行check.cjs。
3. 运行compare.cjs，对dense/gap两个补丁作决定，保存副本差异和原失败。

## 提交与自查

提交一张证据单及本任务实际产物，保留原判断、修订、本人/AI贡献和未测范围。

- 原反例真实复现。
- 副本修复击中结束日。
- 补丁比较使用gap反例。
- 范围/差异/解释可回查。

四项各0/1，仅作本微任务形成性自查。待补证据登记待补，未执行不能算实际操作通过。课程正式成绩归属由教师另行公布。

## 能力范围

- A27　真实修改/对比/解释，未调用AI不计AI代码生成。

微任务范围对齐当前选编，固定情境为明确标注的课堂构造。

## 副本根目录中的操作入口

以下命令在整个student工作副本根目录执行。保存输出时先保留已有同名文件。注释行是人工编辑要求，不是已完成记录。

```sh
node runtime/b06/run.cjs
cp runtime/b06/boundary-candidate.js runtime/b06/learner-candidate.cjs
# 用文本编辑器在learner-candidate.cjs只把row.date < payload.range.end改为row.date <= payload.range.end
node runtime/b06/check.cjs runtime/b06/learner-candidate.cjs
node runtime/b06/compare.cjs
```

## 概念使用边界

构造补丁实际修改与审查，不声称本次对话式AI编程。
