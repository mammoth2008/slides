# U11 本地练习入口

从本目录作为整个 student 工作副本根目录。原任务、输入和合同分别在 units/U11，唯一必需媒体在 media/b04-visual-review/poster-a.svg。它是课程自制的虚构换书日海报。原字节与来源被保留

## 开始前

需已有免费纯文本编辑器。将本目录复制到个人工作目录，保留已有同名文件。打开 units/U11/task.md，先读 input.json 中 requestedChange 和 mechanismBoundary。没有编辑工具时先记录待执行，由教师补充条件，计划不能记成已经修改

## 实际操作

1. 复制 media/b04-visual-review/poster-a.svg 为同目录 poster-edited.svg，先核对正在编辑副本
2. 用纯文本模式打开副本，查找唯一的 11月20日，改为 11月21日，UTF-8保存。不要更动时间14:00—17:00
3. 保留原/新SHA或源码差异，逐项检查其它文字、颜色、画幅、书/杯图形。若已有系统查看器，可查看前后效果。无查看条件则把视觉保持项记待看

源码核对可用既有编辑器的比较功能。Mac已有终端可在 student 根目录选用以下命令，只读取文件

```sh
diff -u media/b04-visual-review/poster-a.svg media/b04-visual-review/poster-edited.svg
shasum -a 256 media/b04-visual-review/poster-a.svg media/b04-visual-review/poster-edited.svg
```

差异命令有变化时正常返回1，应读取输出判定。原SVG是一整行，比较会显示整行，仍需定位真正不同的日期字符。SHA不同只能说明字节有变，不能说明只改了日期。输出未保存时可复制差异文本到证据单

## 证据单

复制 evidence-template.md，以原合同的四部分保留初判、实际步骤、最终文件与决定、方法和未测/本人AI贡献。提交证据单和实际修订SVG，原件与核对记录保留。四项C1–C4各0/1，缺证据标待补，总4分只作形成性自查，正式成绩由教师另行公布

public-variant-v2.json 是公开条件变化练习，日期目标改为11月22日。它在原30分钟微任务后另用，原任务仍按11月21日。它不是教师后发未见考核，不增改原任务评分
