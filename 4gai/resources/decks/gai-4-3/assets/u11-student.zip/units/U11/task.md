# U11 参考与局部修改的保留约束

候选形成性练习。建议30分钟，学生耗时尚未验证。仅提交本页微任务，不承接可选整题的完整交付或100分量规。

## 固定材料

读取本目录input.json。以下内容可打印使用。

```json
{
  "assetId": "IMG-001",
  "editableFile": "../../media/b04-visual-review/poster-a.svg",
  "requestedChange": "虚构主办方将日期从11月20日改为11月21日，只改此日期，其余文字、颜色、画幅及书/杯图形保留。",
  "operation": "复制poster-a.svg为poster-edited.svg。用系统纯文本编辑器的纯文本模式或既有代码编辑器，将唯一的11月20日改为11月21日，保存UTF-8 SVG。不要改原件。可由系统预览查看，两文件源码差异也须保留。",
  "mechanismBoundary": "本次是手工SVG文字编辑。局部重绘、蒙版、去噪强度是概念背景，本次不运行扩散重绘，不从手工成功推断生成机制。",
  "provenance": "identified_source_excerpt_and_teaching_construct",
  "backgroundSources": [
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/question-bank/records/Q-132.json",
      "sha256": "5fa35f70ebef2afcf5e95e33e2b065183b448524b7030fcd3b6ece31c7544839",
      "locator": "/inputs"
    },
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/cases/records/CASE-009.json",
      "sha256": "315e87fd20418c27b97950f1695dd829e56585fdac6aa95941a0045eb58b350a",
      "locator": "/studentTask/inputs"
    },
    {
      "path": "courses/gai/knowledge-map/content/nodes/A21.json",
      "sha256": "a43d47b635cb313176abb1d3f4222702ce9822beecbe56260def4e745aa73d12",
      "locator": "whole_file"
    }
  ]
}
```

实际文件见以下清单。媒体为原字节副本。替代文字只支持相应的文字判断，不充作本人视听证据。

- [IMG-001](../../media/b04-visual-review/poster-a.svg)

## 必要动作

1. 复制原SVG为poster-edited.svg，保存原件。
2. 在免费本地文本编辑器实际仅替换日期11月20日→11月21日，保存SVG。
3. 记录原/新文件SHA或源码差异，逐项检查其它文字和图形结构，作采用决定。无查看条件时视觉保持项记待看。

## 提交与自查

提交一张证据单及本任务实际产物，保留原判断、修订、本人/AI贡献和未测范围。

- 取得实际修订SVG。
- 仅日期文本变更且原件保留。
- 目标与保留结构有前后证据。
- 手工编辑和生成机制边界准确。

四项各0/1，仅作本微任务形成性自查。待补证据登记待补，未执行不能算实际操作通过。课程正式成绩归属由教师另行公布。

## 能力范围

- A21　手工SVG局部改动和保留核查，不等同扩散重绘实操。

现选编概念可作背景，实际路径为手工SVG编辑。

## 副本根目录中的操作入口

以下命令在整个student工作副本根目录执行。保存输出时先保留已有同名文件。注释行是人工编辑要求，不是已完成记录。

```sh
用本地纯文本编辑器打开media/b04-visual-review/poster-a.svg的副本，按input.json仅改日期；用系统预览打开前后文件。
```

## 概念使用边界

手工SVG日期编辑，参考图/局部保留解释可观察，蒙版/去噪强度/扩散局部重绘仅背景。
