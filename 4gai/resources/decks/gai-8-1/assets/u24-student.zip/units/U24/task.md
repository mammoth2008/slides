# U24 综合治理判断与个人解释

候选形成性练习。建议30分钟，学生耗时尚未验证。仅提交本页微任务，不承接可选整题的完整交付或100分量规。

## 固定材料

读取本目录input.json。以下内容可打印使用。

```json
{
  "scenario": {
    "name": "虚构青禾咨询草稿服务",
    "version": "0.1",
    "quality": "公开规则问答10条中1条错误，课堂门槛错误率≤10%。样本为构造，不代表未来。",
    "allowed": "仅内部草稿，不能决定资格或截止；高影响决定人工复核。",
    "roles": [
      "课程教师可给学习反馈，不可替IT撤令牌",
      "值班经理可暂停本地任务并接人工",
      "IT可撤实际服务令牌并返回证据"
    ],
    "currentEvidence": "没有真实部署、费用、个人项目实测或撤销记录。"
  },
  "initialTask": "停止AI与同伴代作，先写当前可采用范围、条件和责任，保留v1；封存后等教师另发未见约束。",
  "missingCard": "未获教师卡时只交v1和待测声明，独立迁移保持待测，教师后补同等时长；不扣学生未发卡的分。",
  "studentWarning": "公开卡为练习，独立未见条件由教师另发。不得提前读教师目录。",
  "provenance": "teaching_construct",
  "backgroundSources": [
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/question-bank/records/Q-603.json",
      "sha256": "4d44aa0b21bd932c1a475e3c4153421e44193a85f12bf9c36a8b45aeabb3cf0c",
      "locator": "/inputs"
    },
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/cases/records/CASE-019.json",
      "sha256": "c29a6bbe2a62f1fadd91d8123a99e9487f16703b453c479684a4b4ac6446cf91",
      "locator": "/studentTask/inputs"
    },
    {
      "path": "courses/gai/knowledge-map/content/nodes/A08.json",
      "sha256": "5c002a32b5c5a6fde83bbd8fdd4ed3cb6606c66c7b221150a20a17eecabd0ccb",
      "locator": "whole_file"
    },
    {
      "path": "courses/gai/knowledge-map/content/nodes/A41.json",
      "sha256": "9909d149a585c058eb6519ce01bb41b85d7896eb15c4409d3e9c3b25914f5fe0",
      "locator": "whole_file"
    }
  ]
}
```

## 必要动作

1. 关闭AI及同伴代作，独立交公开条件下v1决定与个人项目待补证据。
2. 按教师指令封存v1后接收后发卡，停止AI独立交v2，保留决定改变或维持的理由。
3. 未发卡交待测声明，后补同等时长，不代造约束或真实项目数据。

## 提交与自查

提交一张证据单及本任务实际产物，保留原判断、修订、本人/AI贡献和未测范围。

- v1在发卡前封存。
- v2独立且依据新约束。
- 决定和责任触发条件明确。
- 个人作品未知不补造且缺发保持待测。

四项各0/1，仅作本微任务形成性自查。待补证据登记待补，未执行不能算实际操作通过。课程正式成绩归属由教师另行公布。

## 能力范围

- A08　教学情景采用/暂停权衡。
- A41　限定工具下未见约束独立迁移，只有教师实际发卡与独立产物才可取证。

微任务范围对齐当前选编，固定情境为明确标注的课堂构造。

## 概念使用边界

只支持固定卡中的相关解释，不登记整个概念或能力达成。
