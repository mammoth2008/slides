# U15 视频生成与时序检查

候选形成性练习。建议30分钟，学生耗时尚未验证。仅提交本页微任务，不承接可选整题的完整交付或100分量规。

## 固定材料

读取本目录input.json。以下内容可打印使用。

```json
{
  "assetIds": [
    "VID-008"
  ],
  "durationSeconds": 2.041667,
  "frames": 49,
  "fps": 24,
  "brief": "实际生成湖景，提示要求日出山湖、一艘空木船从画面左向右缓慢漂移、轻涟漪、远岸松树薄雾、暖光、固定摄影机、连续单镜头。",
  "rules": [
    "通看片段后按0—0.7/0.7—1.4/1.4—2.042秒记主体/动作/连续性证据。",
    "用前景、远岸和取景边界分别参照，运动方向证据不足可记不能判定。",
    "无声片，不评价配音。此卡不使用Q142纸盒/6秒/A17观察表。",
    "描述VTT是替代阅读，不等于本人已看原片。"
  ],
  "provenance": "identified_source_excerpt_and_teaching_construct",
  "backgroundSources": [
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/question-bank/records/Q-142.json",
      "sha256": "47f24f5604bacd322f0be66f1a32e959c062b60964ba0aeade3fa3a396086ec3",
      "locator": "/inputs"
    },
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/cases/records/CASE-010.json",
      "sha256": "18fcec642af7fe94824faaf3caa3880d7f9e418095502aff9d677e748c632cb7",
      "locator": "/studentTask/inputs"
    },
    {
      "path": "courses/gai/knowledge-map/content/nodes/A24.json",
      "sha256": "2b24e6a5df179f7d001449abb44d0e70d51d542fd0484f76c81601683a7a1de0",
      "locator": "whole_file"
    }
  ]
}
```

实际文件见以下清单。媒体为原字节副本。替代文字只支持相应的文字判断，不充作本人视听证据。

- [VID-008](../../media/b05-comfyui-video/originals/lake-20261105.mp4)

## 必要动作

1. 实际通看VID008，再按三个时间段记录主体、动作与连续性。
2. 选择前景/远岸/取景边界参照，说明船方向与镜头是否有充分证据。
3. 作选用/暂停/补查决定，保留无法判断项，不套用纸盒观察表。

## 提交与自查

提交一张证据单及本任务实际产物，保留原判断、修订、本人/AI贡献和未测范围。

- 完整片与抽帧范围分开。
- 观察附真实时间段。
- 方向/镜头分别依据参照。
- 未判定与选用条件保留。

四项各0/1，仅作本微任务形成性自查。待补证据登记待补，未执行不能算实际操作通过。课程正式成绩归属由教师另行公布。

## 能力范围

- A24　单段真实生成视频的时序/连续性验收，不含声音整合。

微任务范围对齐当前选编，固定情境为明确标注的课堂构造。

## 概念使用边界

VID008为文生视频，图生视频仅可作对比背景，不声称运行。
