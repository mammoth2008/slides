# U12 系列一致性与采用说明

候选形成性练习。建议30分钟，学生耗时尚未验证。仅提交本页微任务，不承接可选整题的完整交付或100分量规。

## 固定材料

读取本目录input.json。以下内容可打印使用。

```json
{
  "assetIds": [
    "IMG-001",
    "IMG-002"
  ],
  "rules": {
    "brand": "虚构拾页换书日",
    "fixed": [
      "标题“让读过的故事继续走下去。”",
      "日期11月20日",
      "14:00—17:00",
      "图书馆一层·交换区",
      "米白/深绿配色"
    ],
    "variable": [
      "杯子可删",
      "书堆位置可微调但不可遮字"
    ]
  },
  "rightsRecord": "两幅SVG为课程原创程序绘制教学图，无外部照片/人物/模型输出。模型许可项填不适用并说明原因，不能伪造扩散模型许可证。可离线课堂审阅和编辑，真实商业发布须按实际用途另核。",
  "taskBoundary": "只审这两幅实际图。名称“拾页”及规则均为教学构造，与Q137文字品牌不同，不混用。",
  "provenance": "identified_source_excerpt_and_teaching_construct",
  "backgroundSources": [
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/question-bank/records/Q-137.json",
      "sha256": "d34d78ea0bfc895989249d8b3453b9a04965a3c3756bc701105e0622c53a6f38",
      "locator": "/inputs"
    },
    {
      "path": "courses/gai/course-construction/2025/03-teaching-resources/cases/records/CASE-009.json",
      "sha256": "315e87fd20418c27b97950f1695dd829e56585fdac6aa95941a0045eb58b350a",
      "locator": "/studentTask/inputs"
    },
    {
      "path": "courses/gai/knowledge-map/content/nodes/A22.json",
      "sha256": "01b2ced0c19af2b683d04cbf65165b9436580195c57e57c2c781af2aa001e7af",
      "locator": "whole_file"
    },
    {
      "path": "courses/gai/knowledge-map/content/nodes/A25.json",
      "sha256": "8b2cbdac0977f5ad89e64b615a5675f01d631b29ff2a6dff8b3d3cf7432bb70d",
      "locator": "whole_file"
    }
  ]
}
```

实际文件见以下清单。媒体为原字节副本。替代文字只支持相应的文字判断，不充作本人视听证据。

- [IMG-001](../../media/b04-visual-review/poster-a.svg)
- [IMG-002](../../media/b04-visual-review/poster-b.svg)

## 必要动作

1. 分别查看两幅真实SVG或读其源码文字，按同一规则列逐件检查。
2. 跨件比较日期、标题、配色、杯子是否属于允许变化，给采用/待修决定。
3. 列素材原创身份、人工改动、模型许可不适用及实际发布边界。

## 提交与自查

提交一张证据单及本任务实际产物，保留原判断、修订、本人/AI贡献和未测范围。

- 两幅实际素材逐项可查。
- 跨件变化按共同规则判。
- 素材权利和人工改动记录。
- 模型许可不适用有事实依据。

四项各0/1，仅作本微任务形成性自查。待补证据登记待补，未执行不能算实际操作通过。课程正式成绩归属由教师另行公布。

## 能力范围

- A22　双素材一致性审阅。
- A25　自制SVG与用途权利记录，非真实法律合规结论。

使用模型许可不适用状态，其余权利核查保持。

## 概念使用边界

本包SVG为程序自制，模型许可不适用判断有证据，但不证明能解释某模型许可证。
