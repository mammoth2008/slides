# 11.1 标识解析与生命周期（10分钟）

课程自制教学数据；example.org与全零GTIN均为占位，不是商业分配的商品码。本任务不访问网站、不调用摄像头、不操作真实设备。

```sh
python identify.py
python identify.py --retire DEMO-001
python identify.py --uri https://example.org/01/00000000000000/21/UNKNOWN-999
```

每次从registry.json重新读入：前两项active，第三项retired。第二条命令只在本次内存中将DEMO-001设为retired，不改原始文件。

提交：GTIN、序列号、平台ID、状态四列，解释相同GTIN为什么可以对应不同实物。再说明退役、认证、授权分别回答什么。

脚本仅支持本例 `/01/{14位数字}/21/{序列号}` 路径，不是完整GS1标准验证器，不验证商业分配或实物真伪。增加一个未登记序列号时应输出UNKNOWN，而不是随便创建有效对象。

参考：https://ref.gs1.org/standards/digital-link/uri-syntax/ （审阅时1.7.0，2026-08）；这里只借用URI语法展示标识粒度。

## 换锁记录阅读

vehicle-bindings.csv 与 lock-requests.csv 是另一组课堂合成记录，用于复核课件中的 B017 换锁。有效区间包含起点、不包含结束点；空结束时间表示尚未结束。对照10:05的两条请求：L055绑定已结束，L056绑定仍有效。绑定有效不等于发送者已通过认证或获准开锁。本组按表格手工核对，identify.py仍只处理上面的商品序列号示例。
