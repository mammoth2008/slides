from pathlib import Path
from urllib.parse import urlparse,unquote
import argparse,json,re
p=argparse.ArgumentParser();p.add_argument('--retire');p.add_argument('--uri');a=p.parse_args()
registry=json.loads((Path(__file__).parent/'registry.json').read_text(encoding='utf-8'))
for row in registry:
    if row['serial']==a.retire: row['status']='retired'
uris=[a.uri] if a.uri else ['https://example.org/01/'+r['gtin']+'/21/'+r['serial'] for r in registry]
for uri in uris:
    match=re.fullmatch(r'/01/(\d{14})/21/([^/]+)',urlparse(uri).path)
    if not match: raise ValueError('Unsupported teaching URI structure')
    gtin,serial=match[1],unquote(match[2])
    found=next((r for r in registry if (r['gtin'],r['serial'])==(gtin,serial)),None)
    print(json.dumps(dict(gtin=gtin,serial=serial,object_id=found['object_id'] if found else None,status=found['status'] if found else 'UNKNOWN'),ensure_ascii=False))
