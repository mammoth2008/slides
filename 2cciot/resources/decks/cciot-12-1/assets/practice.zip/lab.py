import argparse,math
p=argparse.ArgumentParser()
p.add_argument('--r3',type=float,default=5)
p.add_argument('--forward',type=float,default=4)
p.add_argument('--backward',type=float,default=4)
a=p.parse_args()
if min(a.r3,a.forward,a.backward)<0:p.error('distances and delays must be nonnegative')
x=3;y=(25-a.r3*a.r3+64)/16
residuals=[math.dist((x,y),anchor)-r for anchor,r in [((0,0),5),((6,0),5),((0,8),a.r3)]]
print(f'position candidate=({x:.4f},{y:.4f}), residuals={[round(r,4) for r in residuals]}')
true_offset=14;processing=2;t1=1000
t2=t1+a.forward+true_offset;t3=t2+processing;t4=t1+a.forward+processing+a.backward
offset=((t2-t1)+(t3-t4))/2;delay=(t4-t1)-(t3-t2)
print('timestamps=',[t1,t2,t3,t4])
print(f'offset estimate={offset:.2f}ms, true offset={true_offset}ms, network RTT={delay:.2f}ms')
