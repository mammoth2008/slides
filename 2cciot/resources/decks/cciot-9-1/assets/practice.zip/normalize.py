from pathlib import Path
import json
rows=json.loads((Path(__file__).parent/'observations.json').read_text(encoding='utf-8'))
for row in rows:
    unit=row['unit']
    if unit not in ('ratio','%'): raise ValueError('Unknown unit: '+unit)
    value=float(row['value'])*(100 if unit=='ratio' else 1)
    if not 0<=value<=100: raise ValueError('Out of range')
    print(json.dumps(dict(raw=row,normalized_value=round(value,4),normalized_unit='%'),ensure_ascii=False))
