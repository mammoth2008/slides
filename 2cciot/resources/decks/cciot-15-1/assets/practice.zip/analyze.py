from pathlib import Path
from datetime import datetime
import csv
base=Path(__file__).parent
raw=list(csv.DictReader((base/'raw.csv').open(encoding='utf-8')));unique={}
for row in raw:
    key=row['record_id']
    if key in unique and unique[key]!=row: raise ValueError('conflicting duplicate '+key)
    unique[key]=row
rows=[]
for row in unique.values():
    if row['unit'] not in ['ratio','%']: raise ValueError('unknown unit')
    value=None if row['value']=='' else float(row['value'])*(100 if row['unit']=='ratio' else 1)
    if value is not None and not 0<=value<=100: raise ValueError('out of range')
    rows.append(dict(row,normalized_value=value))
rows.sort(key=lambda r:datetime.fromisoformat(r['timestamp']))
cutoff=datetime.fromisoformat('2026-10-13T10:40:00+08:00')
train=[r for r in rows if datetime.fromisoformat(r['timestamp'])<cutoff]
validation=[r for r in rows if datetime.fromisoformat(r['timestamp'])>=cutoff]
reference={r['record_id']:float(r['reference_moisture_pct']) for r in csv.DictReader((base/'label_reference.csv').open(encoding='utf-8'))}
for r in rows:
    if int(r['label_alarm']) != int(reference[r['record_id']]<30):
        raise ValueError('label and synthetic reference disagree: '+r['record_id'])
values=[r['normalized_value'] for r in train if r['normalized_value'] is not None]
mean=sum(values)/len(values)
for r in rows:
    if r['normalized_value'] is None:r['normalized_value']=mean
print(f'raw={len(raw)}, unique={len(rows)}, train={len(train)}, validation={len(validation)}, train_mean={mean:.4f}')
pred={r['record_id']:int(r['pred_alarm']) for r in csv.DictReader((base/'candidate_predictions.csv').open(encoding='utf-8'))}
for name,predict in [('threshold',lambda r:int(r['normalized_value']<30)),('given_candidate',lambda r:pred[r['record_id']])]:
    tp=fn=fp=tn=0
    for r in validation:
        truth=int(r['label_alarm']);guess=predict(r)
        if truth and guess:tp+=1
        elif truth:fn+=1
        elif guess:fp+=1
        else:tn+=1
    precision=tp/(tp+fp) if tp+fp else 0;recall=tp/(tp+fn) if tp+fn else 0
    print(f'{name}: TP={tp} FN={fn} FP={fp} TN={tn}; precision={precision:.1%} recall={recall:.1%} accuracy={(tp+tn)/len(validation):.1%}')

print('label rule: synthetic reference moisture < 30 => inspection reminder; reference is not a prediction input')
for r in validation:
    if r['record_id'] in ['r043','r130']:
        print(f"{r['record_id']}: probe={r['normalized_value']:g}%, reference={reference[r['record_id']]:g}%, label={r['label_alarm']}")
print('Selection uses validation only; final independent test set is not supplied')
