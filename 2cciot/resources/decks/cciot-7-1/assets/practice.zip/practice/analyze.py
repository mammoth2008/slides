"""Read synthetic access logs; no network requests or writes."""
from pathlib import Path
import csv
from collections import Counter
rows=list(csv.DictReader((Path(__file__).parent/'access.csv').open(encoding='utf-8')))
print('requests:',len(rows))
print('status:',dict(sorted(Counter(r['status'] for r in rows).items())))
for r in rows:
    if int(r['status'])>=400: print(r['time'],r['path'],r['status'])
print('Visitor count cannot be inferred from these fields.')
