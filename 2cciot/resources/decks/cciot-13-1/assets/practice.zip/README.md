# 13.1 MQTT收发与消息诊断（15分钟）

课程自制合成消息。真实收发需要预装Mosquitto broker和mosquitto_pub/sub；Python 3用于应用消息检查。2026-10-20修订环境未找到Mosquitto，以下收发命令尚未实机验证，教师须课前确认。文件输入诊断可独立运行。

## 操作单位：同一台电脑的三个终端

教师可以在自己的电脑演示整组步骤；学生独立操作时，每台电脑都需要安装并启动自己的broker。127.0.0.1指运行命令的本机，不能用它连接另一台教师电脑。以下为WSL/Linux/macOS shell命令，三个终端均先进入解压后的练习目录。

终端0启动代理，配置仅监听127.0.0.1:18883，匿名访问仅用于本机教学，不对教室网络开放：

```sh
mosquitto -c mosquitto.conf
```

终端A先启动订阅，收满三条消息后退出。这里不加-v，确保文件每条只有JSON payload，不带主题前缀；它会覆盖本目录同名received.jsonl：

```sh
mosquitto_sub -h 127.0.0.1 -p 18883 -t cciot/plot-A/moisture -q 1 -C 3 > received.jsonl
```

终端B依次发布。两次发送normal.json是人为主动重放同一message_id，不是网络自动重复的证明：

```sh
mosquitto_pub -h 127.0.0.1 -p 18883 -t cciot/plot-A/moisture -q 1 -f normal.json
mosquitto_pub -h 127.0.0.1 -p 18883 -t cciot/plot-A/moisture -q 1 -f normal.json
mosquitto_pub -h 127.0.0.1 -p 18883 -t cciot/plot-A/moisture -q 1 -r -f stale.json
```

确认A已退出，再在A检查刚收到的文件：

```sh
python inspect_messages.py --input received.jsonl
```

脚本打印实际输入路径与参考时刻。消息均含device_id、object_id、message_id、value、unit、timestamp；诊断使用设备编号、消息编号和采样时间。参考时刻固定为2026-10-13T10:00:10+08:00，最大年龄60秒；这是复现实验的教学时钟，不是此刻真实时间。预期正常值年龄10秒为ACCEPT，第二条DUPLICATE，旧值年龄3610秒为STALE。处理真实采样时，应使用真实采样时间并通过--now提供对应的当前时刻。

## 新订阅检查保留值

终端A重新订阅，只接收一条；预期立即得到m002，且应用检查仍判STALE：

```sh
mosquitto_sub -h 127.0.0.1 -p 18883 -t cciot/plot-A/moisture -q 1 -C 1 > retained.jsonl
python inspect_messages.py --input retained.jsonl
```

两次订阅都结束后，在B清理保留值，再用Ctrl+C结束终端0的broker：

```sh
mosquitto_pub -h 127.0.0.1 -p 18883 -t cciot/plot-A/moisture -r -n
```

若上次操作中断，先停止旧订阅、清理保留值，再从终端A的三条订阅开始；否则旧保留值可能先占用一条计数。没有收到预期条数时，检查三个终端是否同机、主题是否相同、broker是否正在运行；用Ctrl+C终止等待。

## 没有broker时的独立任务

```sh
python inspect_messages.py
```

这次输入是包内messages.jsonl，含预置正常、重复与过期消息，预期也是ACCEPT、DUPLICATE、STALE。它验证应用规则，不证明MQTT联通，也不是刚才终端收到的数据。

提交文件来源、原始消息、处理结果及理由；把实际收发与预置日志分别标记。去重集合仅在本进程中，不具备持久化和事务能力；未控制真实阀门。完成后自行保留或删除本次生成的received.jsonl与retained.jsonl。

参考为既有来源：https://docs.oasis-open.org/mqtt/mqtt/v5.0/mqtt-v5.0.html 、https://mosquitto.org/man/mosquitto_pub-1.html 、https://www.mosquitto.org/man/mosquitto_sub-1.html ，本轮未联网复核。
