from pathlib import Path
from datetime import datetime
import argparse,json

p=argparse.ArgumentParser(description='Inspect captured payload JSONL or the supplied teaching log')
p.add_argument('--input',type=Path,default=Path(__file__).parent/'messages.jsonl')
p.add_argument('--now',default='2026-10-13T10:00:10+08:00',help='Reference time; defaults to the fixed classroom time')
a=p.parse_args()
now=datetime.fromisoformat(a.now)
if now.tzinfo is None:p.error('--now must include a timezone')
seen=set()
print('input=',a.input.resolve(),'reference=',now.isoformat(),'max_age=60s')
for number,line in enumerate(a.input.read_text(encoding='utf-8').splitlines(),1):
    if not line.strip():continue
    try:
        m=json.loads(line)
        key=(m['device_id'],m['message_id'])
        timestamp=datetime.fromisoformat(m['timestamp'])
        if timestamp.tzinfo is None:raise ValueError('timestamp must include a timezone')
        age=(now-timestamp).total_seconds()
    except (ValueError,KeyError,TypeError) as exc:
        raise ValueError(f'Invalid payload on line {number}: {exc}') from exc
    if age<0: result='FUTURE_TIMESTAMP'
    elif age>60: result='STALE'
    elif key in seen: result='DUPLICATE'
    else: result='ACCEPT';seen.add(key)
    print(m['device_id'],m['message_id'],f'age={age:.0f}s',result)
