"""Local teaching simulation; no real device, authentication or persistent state."""
from pathlib import Path
import argparse
import json
import math


def run_scenario(scenario, threshold):
    mode = scenario['initial_mode']
    valve = scenario['initial_valve']
    state_version = 0
    executions = 0
    for seq, event in enumerate(scenario['events'], 1):
        before = (mode, valve)
        trigger = event['event']
        action = 'none'
        if trigger == 'observation':
            value = event['value']
            if not math.isfinite(value) or not 0 <= value <= 100:
                raise ValueError('moisture must be 0..100 percent')
            conditions = {
                'auto_mode': mode == 'auto',
                'water_available': event['water_available'],
                'below_threshold': value < threshold,
            }
            if all(conditions.values()):
                valve = 'open'
                action, result = 'open', 'EXECUTED'
                executions += 1
            else:
                result = 'CONDITION_BLOCKED'
        elif trigger in ('manual_close', 'resume_auto'):
            # Trusted classroom fixture, not authentication of a real operator.
            conditions = {'authorized_fixture': event['principal'] == 'operator'}
            if not conditions['authorized_fixture']:
                result = 'DENIED'
            elif trigger == 'manual_close':
                mode, valve = 'manual', 'closed'
                action, result = 'close', 'MANUAL_OVERRIDE'
                executions += 1
            else:
                mode = 'auto'
                action, result = 'resume_auto', 'AUTO_RESUMED'
                # Resuming changes mode only; a new observation must be checked.
        else:
            raise ValueError(f'unknown event: {trigger}')
        if before != (mode, valve):
            state_version += 1
        yield {
            'case': scenario['case'], 'seq': seq, 'simulation': True,
            'device_id': 'soil-01', 'object_id': 'plot-A',
            'controller_id': 'controller-01', 'actuator_id': 'valve-01',
            'event_id': event['event_id'], 'timestamp': event['timestamp'],
            'value': event.get('value'), 'unit': '%' if trigger == 'observation' else None,
            'principal': event.get('principal'),
            'rule_version': f'demo-threshold-{threshold:g}', 'threshold': threshold,
            'trigger': trigger, 'conditions': conditions,
            'action': action, 'result': result,
            'reported_valve': valve, 'mode': mode,
            'state_version': state_version, 'valve_executions': executions,
        }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--threshold', type=float, default=30)
    parser.add_argument('--cases', type=Path, default=Path(__file__).with_name('cases.json'))
    args = parser.parse_args()
    if not math.isfinite(args.threshold) or not 0 <= args.threshold <= 100:
        parser.error('threshold must be 0..100 percent')
    for scenario in json.loads(args.cases.read_text(encoding='utf-8')):
        for record in run_scenario(scenario, args.threshold):
            print(json.dumps(record, ensure_ascii=False))


if __name__ == '__main__':
    main()
