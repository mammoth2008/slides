# 17.1 灌溉综合案例（15—20分钟）

本地Python教学模型，全部数据、设备状态和反馈均为课程自制模拟。soil-01观测plot-A的土壤湿度，controller-01判断条件，valve-01模拟执行；不联网、不操作真实阀门。使用已有Python 3，无需额外软件包

## 运行与预测

解压ZIP，在含automation.py的文件夹打开终端，运行：

```sh
python automation.py
python automation.py --threshold 20
```

每次运行输出八行JSON。先按下面的场景和字段读默认结果，再预测阈值改成20后哪些动作会消失，最后执行第二条命令核对。系统若使用python3作为命令名称，请相应替换

## 两个独立分支与一个连续过程

cases.json中三个case各从auto、closed、状态版本0开始；第三个case内六个事件连续处理，中途不重置

| case | 事件与默认阈值30下的结果 |
| --- | --- |
| normal | 湿度25%，水源可用，开阀，EXECUTED |
| condition_blocked | 湿度25%，水源不可用，保持关闭，CONDITION_BLOCKED |
| manual_cycle | 按下表连续处理六个事件 |

| seq | 事件 | result | 事件后的mode / 阀门 / state_version |
| --- | --- | --- | --- |
| 1 | 新湿度25% | EXECUTED | auto / open / 1 |
| 2 | operator手动关闭 | MANUAL_OVERRIDE | manual / closed / 2 |
| 3 | 新湿度24% | CONDITION_BLOCKED | manual / closed / 2 |
| 4 | viewer请求恢复自动 | DENIED | manual / closed / 2 |
| 5 | operator恢复自动 | AUTO_RESUMED | auto / closed / 3 |
| 6 | 新湿度24% | EXECUTED | auto / open / 4 |

第三个case中水源始终可用。operator预置有权接管或恢复，viewer预置无权；本例不实现身份认证。恢复auto只改变模式，不使用旧读数立即开阀，须等待新的观测并重新检查条件

## 怎样读输出

- case区分场景，seq记录场景内事件次序；event_id标记输入，timestamp记录合成事件时间
- value和unit是湿度读数与百分数单位；手动请求没有湿度读数
- trigger是新观测或人工请求；conditions列出各条件是否通过
- threshold与rule_version说明本次规则；湿度必须严格小于阈值，等于阈值不通过
- action是本次请求的动作，reported_valve是模拟状态，mode为auto或manual
- state_version只在mode或阀门状态改变时增加，不能代替每条都增加的seq
- valve_executions统计开关阀请求，恢复模式不计入开关动作

threshold=20时，normal以及接管过程第1、6步的开阀都被阻止；人工关闭、越权拒绝与授权恢复仍会发生。接管过程的状态版本将是0、1、1、1、2、2，因为此时开阀从未发生

## 个人交付与重置

复制report-template.md，完成一处参数修改并解释结果，附按case分组的八条输出。引用前节已有记录说明方法，标明原对象与本例地块的区别，不能把车辆、AGV或医疗数据冒充灌溉观测。无需重新搭建每一个系统；前节材料缺失时，先完成本包，并把缺口如实写入报告。将报告链接加入7.1个人作品集

rubric.csv提供4项0—2的课堂反馈，不修改正式成绩。重新运行脚本即从初始状态开始，不保存上次状态；若修改cases.json，保留原副本，或重新解压恢复

这个模型只检验预置事件下的规则与接管顺序，不证明持续灌溉、节水或实际授权。尚未实现真实水流反馈、认证、持久化、重复消息处理、失效保护和完整停止逻辑；不能直接用于真实农业控制

## 参考与扩展

沿用2026-10-13的来源核对，本轮未联网更新

- [Home Assistant排障方法](https://www.home-assistant.io/docs/automation/troubleshooting/)：借用trigger、condition、action和trace的解释思路，本包不是Home Assistant配置
- [Matter互操作说明](https://csa-iot.org/all-solutions/matter/)：用于区分应用互操作与网络连接，不要求采购或安装
