"""Pure teaching simulation; no hardware, network or filesystem mutation."""
import argparse,json
p=argparse.ArgumentParser()
p.add_argument('--moisture',type=float,required=True)
p.add_argument('--threshold',type=float,default=30)
p.add_argument('--mode',choices=['monitor','control'],default='monitor')
a=p.parse_args()
if not (0<=a.moisture<=100 and 0<=a.threshold<=100): p.error('percentage must be between 0 and 100')
action='no_control' if a.mode=='monitor' else ('open_requested' if a.moisture<a.threshold else 'no_open_request')
print(json.dumps(dict(simulation=True,device_id='soil-01',object_id='plot-A',value=a.moisture,unit='%',timestamp='2026-10-13T10:00:00+08:00',mode=a.mode,action=action),ensure_ascii=False,indent=2))
