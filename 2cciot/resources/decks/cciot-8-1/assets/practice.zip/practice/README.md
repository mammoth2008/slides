# 8.1 监测与控制模拟（8分钟）

课程自制，无第三方依赖。使用已有Python 3，在本目录运行（WSL可用python3）：

```sh
python lab.py --moisture 35 --mode control
python lab.py --moisture 25 --mode control
python lab.py --moisture 25 --mode monitor
```

先预测，再运行。记录value、mode与action。默认阈值为30：低于阈值才产生开阀请求，等于30不会请求开阀。阈值为教学假设，不是农业操作建议。

监测模式没有控制请求，但观测仍可用于提醒与分析。程序不联网、不采集真实传感器，也不控制真实阀门；它只让数据到规则的关系可观察。

保存一组输出供下一节标注设备、网络、平台与应用职责。字段中的时间固定为教学时间，simulation为true；真实运行应由采集环节产生可靠的时间记录。

来源：本轮审阅索引S01（ITU Y.4000/Y.2060），用于区分物联网定义与控制型应用。未把原报告中的Node-RED列为必装环境。
