import json
# Trusted classroom fixtures stand in for an authenticated identity context.
roles={'alice':'viewer','bob':'operator'}
permissions={'viewer':{'read'},'operator':{'read','open','close'}}
requests=[('alice','read',None),('alice','open','cmd-07'),('bob','open','cmd-07'),('bob','open','cmd-07'),('bob','close','cmd-07')]
seen={};state='closed';executions=0
for i,(principal,action,command_id) in enumerate(requests,1):
    role=roles[principal]
    if action not in permissions[role]: result='DENIED'
    elif action=='read': result='ALLOWED_READ'
    elif command_id in seen:
        result='DUPLICATE_NO_ACTION' if seen[command_id]==action else 'COMMAND_ID_CONFLICT'
    else:
        seen[command_id]=action;state={'open':'open','close':'closed'}[action];executions+=1;result='EXECUTED'
    print(json.dumps(dict(log_id=i,principal=principal,role=role,resource_id="soil-01" if action=="read" else "valve-01",action=action,command_id=command_id,result=result,simulated_valve=state,executions=executions),ensure_ascii=False))
