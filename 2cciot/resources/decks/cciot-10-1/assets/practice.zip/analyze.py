from pathlib import Path
import csv,argparse
p=argparse.ArgumentParser();p.add_argument('--offset',type=float,default=0);a=p.parse_args()
rows=list(csv.DictReader((Path(__file__).parent/'readings.csv').open(encoding='utf-8')))
errors=[]
for row in rows:
    ref=float(row['reference_c']);raw=float(row['raw_c']);corrected=raw-a.offset
    error=corrected-ref;errors.append(abs(error))
    print(f'ref={ref:.1f}, raw={raw:.1f}, corrected={corrected:.1f}, error={error:+.2f}')
print(f'MAE={sum(errors)/len(errors):.2f} C')
print('LSB(8/12 bit)=',*[f'{5/(2**n)*1000:.2f}mV' for n in (8,12)])
print('payload bytes/min: raw=960, summary=24; energy not measured')
