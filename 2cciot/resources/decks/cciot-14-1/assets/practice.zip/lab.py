import argparse, json, math

p = argparse.ArgumentParser(description='Local alarm and valve-state classroom model')
p.add_argument('--offline-value', type=float, default=25, help='Offline moisture percentage, 0 to 100')
a = p.parse_args()
if not math.isfinite(a.offline_value) or not 0 <= a.offline_value <= 100:
    p.error('--offline-value must be finite and between 0 and 100')
cache = []
desired, desired_version = 'closed', 1
reported, reported_version = 'closed', 0
reported_at = '2026-10-13T10:00:00+08:00'
for seq, (cloud_link, value) in enumerate([(True,35), (False,a.offline_value), (True,24)], 1):
    timestamp = f'2026-10-13T10:00:0{seq}+08:00'
    if seq == 2:
        desired, desired_version = 'open', 2  # independent cloud request, not the alarm action
    record = dict(seq=seq,device_id='soil-01',object_id='plot-A',value=value,unit='%',timestamp=timestamp)
    cache.append(record)
    if cloud_link:
        # Model: controller receives target, valve executes and reports, report reaches cloud.
        reported, reported_version, reported_at = desired, desired_version, timestamp
        uploaded = [r['seq'] for r in cache]
        cache.clear()
    else:
        uploaded = []
    print(json.dumps(dict(simulation=True,seq=seq,cloud_link=cloud_link,
        measurement=record,
        local_decision=dict(controller_id='controller-01',threshold=30,comparison='<',local_alert=value<30),
        valve_state=dict(device_id='valve-01',desired=desired,desired_version=desired_version,
                         reported=reported,reported_version=reported_version,reported_at=reported_at,
                         pending=desired_version!=reported_version or desired!=reported),
        transfer=dict(uploaded_seq=uploaded,cached_seq=[r['seq'] for r in cache])),ensure_ascii=False))
print('given model latency(ms): local=25, edge=11, remote=170; deadline=50')
